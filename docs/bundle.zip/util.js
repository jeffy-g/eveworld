/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2019 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                      module vars, functions.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const unity = () => {
    return ~~(Math.random() * 255);
};
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                    class or namespace declare.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
var Util;
(function (Util) {
    /**
     * ensure deeeep copy.
     *
     * @param object copy from this object.
     */
    function deepClone(object) {
        return JSON.parse(JSON.stringify(object));
    }
    Util.deepClone = deepClone;
    /**
     * maybe detect "iPhone" or "Android" mobile phone...
     *
     * @export
     */
    // related: see https://www.suzuco.net/entry/php-useragent-method/
    // https://www.of-mokuren.com/blog/archives/296
    function isSmartPhone() {
        const ua = navigator.userAgent;
        return ua.includes("Mobile") && (ua.includes("Android") || ua.includes("iPhone"));
    }
    Util.isSmartPhone = isSmartPhone;
    // // DEVNOTE: 2022/02/09
    // /**
    //  * sleep by milliseconds
    //  * @param ms If it is 4 or less, it is set to 10.
    //  * @returns 
    //  */
    // export function sleep(ms: number): Promise<void> {
    //     (!ms || ms < 5) && (ms = 10);
    //     return new Promise<void>(resolve => setTimeout(resolve, ms));
    // }
    /**
     *
     * @date 2019-01-11
     * @export
     * @returns {[number, number, number]}
     */
    function randomRGBColor() {
        return [Math.random(), Math.random(), Math.random()];
    }
    Util.randomRGBColor = randomRGBColor;
    /**
     *
     * @date 2019-01-11
     * @export
     * @returns {number}
     */
    function randomHexColor() {
        return unity() << 16 | unity() << 8 | unity();
    }
    Util.randomHexColor = randomHexColor;
    /**
     *
     * @date 2019-01-11
     * @export
     * @param {number} alpha
     * @returns {string}
     */
    function randomHexColorA(alpha) {
        if (alpha < 0) {
            alpha = 0;
        }
        else if (alpha > 1) {
            alpha = 1;
        }
        return `rgba(${unity()}, ${unity()}, ${unity()}, ${alpha})`;
    }
    Util.randomHexColorA = randomHexColorA;
    function normalizeSS(value) {
        const fval = Math.round(value * 10) / 10;
        return fval === 1 ? "1.0" : fval === 0 ? "0.0" : fval + "";
    }
    Util.normalizeSS = normalizeSS;
    /**
    * ss-text-0_7, ss-text-null...
    *
    * @date 2019-01-16
    * @param {number} ss security status
    * @returns {string}
    */
    function convertSSClass(ss) {
        const fval = Math.round(ss * 10) / 10;
        let postfix;
        if (fval === 1 || fval === 0) {
            postfix = fval + "_0";
        }
        else if (fval > 0) {
            postfix = fval.toString().replace(".", "_");
        }
        else {
            postfix = "null";
        }
        return "ss-text-" + postfix;
    }
    Util.convertSSClass = convertSSClass;
    /**
     *
     *
     * @date 2019-01-15
     * @export
     * @param {MouseEvent} e
     * @param {{ x: number, y: number }} mouse
     */
    function mousePositionForRayCasting(e, mouse) {
        const element = e.currentTarget;
        const offsetLeft = element ? element.offsetLeft : 0, offsetTop = element ? element.offsetTop : 0, 
        // canvas width, height
        width = element ? element.offsetWidth : window.innerWidth, height = element ? element.offsetHeight : window.innerHeight;
        // x and y coordinate of canvas.
        const x = e.clientX - offsetLeft;
        const y = e.clientY - offsetTop;
        // -1 to +1 の範囲で現在のマウス座標を登録する
        mouse.x = (x / width) * 2 - 1;
        mouse.y = -(y / height) * 2 + 1;
    }
    Util.mousePositionForRayCasting = mousePositionForRayCasting;
    /**
     * @param intersects
     * @param ignoreNames
     * @returns
     * @date 2022/2/8
     */
    function findIntersectedSystem(intersects, ignoreNames) {
        for (let index = 0, end = intersects.length; index < end;) {
            const intersect = intersects[index++];
            const iobject = intersect.object;
            if (iobject.name) {
                for (let idx2 = 0, last = ignoreNames.length; idx2 < last;) {
                    // TODO: 2022/2/8 1:02:36
                    if (ignoreNames[idx2++] === iobject.name)
                        return null;
                }
                return (iobject.type === "Points" || iobject.type === "Mesh") ? intersect : null;
            }
        }
        return null;
    }
    Util.findIntersectedSystem = findIntersectedSystem;
    // /**
    //  * 
    //  *
    //  * @date 2019-01-11
    //  * @export
    //  * @param {THREE.Vector3} start use as reference.
    //  * @param {THREE.Vector3} end   use as reference.
    //  * @param {number} [step=50]
    //  * @returns {EaseDeltaContext}
    //  * 
    //  * @deprecated boring behavior
    //  */
    // export function makeStep(start: THREE.Vector3, end: THREE.Vector3, step: number = 50): EaseDeltaContext {
    //     const result: EaseDeltaContext = { duration: step } as EaseDeltaContext;
    //     result.x = (start.x - end.x) / step;
    //     result.y = (start.y - end.y) / step;
    //     result.z = (start.z - end.z) / step;
    //     return result;
    // }
    /**
     * when start === end, returns `null`.
     *
     * @date 2019-01-11
     * @export
     * @param {THREE.Vector3} start using "clone".
     * @param {THREE.Vector3} end final position. (using reference
     * @param {number} [step=50]
     * @returns {EaseDeltaContext}
     */
    function makeEaseContext(start, end, step = 50) {
        if (start.equals(end)) {
            return null;
        }
        const result = { from: start.clone(), duration: step };
        result.x = end.x - start.x;
        result.y = end.y - start.y;
        result.z = end.z - start.z;
        return result;
    }
    Util.makeEaseContext = makeEaseContext;
    // - - - gist - https://gist.github.com/jeffy-g/28a298b52e19c0e7837c8a92686aaf1f - - -
    /* DEVNOTE: 190119 - complete. */
    // see: https://ics.media/entry/15043/2 - 正面ベクトルの算出方法が大いに参考になった.
    // - - - raw code - - -
    // const cpos = this.camera.position;
    // const pointDistance = cpos.distanceTo(at);
    // const directionVec = at.clone().sub(cpos).normalize();
    // const distanceMultiply = 1 - (UniverseUnit.ly(10) / pointDistance);
    // lasq.lastCameraPosition = directionVec.multiplyScalar(pointDistance * distanceMultiply).add(cpos);
    /*
     * Calculate arbitrary coordinates in a line segment between two points
        // template
        function (from,  to,  distanceMultiply) {
            return from + distanceMultiply * (to - from);
        }
        NOTE:
         1. must need normalize of "to" to "from" substracted Vector.

        @from: https://en.wikipedia.org/wiki/Linear_interpolation -Programming language support
        // #1 Imprecise method, which does not guarantee v = v1 when t = 1, due to floating-point arithmetic error.
        // This form may be used when the hardware has a native fused multiply-add instruction.
        float lerp(float v0, float v1, float t) { // THREE.Vector3.lerp using this type.
          return v0 + t * (v1 - v0);
        }
        // #2 Precise method, which guarantees v = v1 when t = 1.
        float lerp(float v0, float v1, float t) {
          return (1 - t) * v0 + t * v1;
        }

     */
    /**
     *
     *
     * @date 2019-01-19
     * @export
     * @param {THREE.Vector3} from
     * @param {THREE.Vector3} to
     * @param {number} distanceFromTo
     * @returns {THREE.Vector3}
     */
    function arbitraryCoordinatesInLineSeg(from, to, distanceFromTo) {
        /* DEVNOTE: This code is explain, however eventually it can be simplified like the THREE.Vector3.lerp method. */
        // #1.
        // const distance = from.distanceTo(to);
        // const distanceMultiply = 1 - (distanceFromTo / distance);
        // return to.clone().sub(from).normalize().multiplyScalar(distance * distanceMultiply).add(from);
        // #2.
        // const distance = from.distanceTo(to);
        // return _acils(from, to,  distance, 1 - (distanceFromTo / distance));
        // #3.
        const pct = 1 - (distanceFromTo / from.distanceTo(to));
        // DEVNOTE: "lerpVectors" call three methods internally.
        // return _scilsVec.lerpVectors(from, to, pct);
        // DEVNOTE: this code is method call cost are two.
        return _scilsVec.copy(from).lerp(to, pct);
        // return from.clone().lerp(to, pct);
        // https://en.wikipedia.org/wiki/Linear_interpolation #2 だが、結果が異なる...?
        // - - - useing Vector3 methods.
        // const alpha = distanceFromTo / from.distanceTo(to);
        // return _scilsVec.copy(from).multiplyScalar(1 - alpha).add(
        //     to.clone().multiplyScalar(alpha)
        // );
        // - - - manual calclation.
        // const inverseA = 1 - alpha;
        // _scilsVec.x = from.x * inverseA;
        // _scilsVec.y = from.y * inverseA;
        // _scilsVec.z = from.z * inverseA;
        // _scilsVec.x += to.x * alpha;
        // _scilsVec.y += to.y * alpha;
        // _scilsVec.z += to.z * alpha;
        // return _scilsVec;
    }
    Util.arbitraryCoordinatesInLineSeg = arbitraryCoordinatesInLineSeg;
    /** avoid temporary object creation. */
    const _scilsVec = new THREE.Vector3();
    // /**
    //  * @deprecated use from.clone().lerp(to, alpha);
    //  *
    //  * @date 2019-01-19
    //  * @export
    //  * @param {THREE.Vector3} from
    //  * @param {THREE.Vector3} to
    //  * @param {number} alpha Percentage up to the final point "to". (0 to 1)
    //  * @returns {THREE.Vector3}
    //  */
    // export function arbitraryCoordinatesInLineSegByUnit(from: THREE.Vector3, to: THREE.Vector3, alpha: number): THREE.Vector3 {
    //     // #1.
    //     // const distance = from.distanceTo(to);
    //     // return to.clone().sub(from).normalize().multiplyScalar(distance * alpha).add(from);
    //     // #2.
    //     // return _acils(from, to,  from.distanceTo(to), alpha);
    //     // #3.
    //     return from.clone().lerp(to, alpha);
    // }
    // function _acils(from: THREE.Vector3, to: THREE.Vector3, distance: number, pct: number): THREE.Vector3 {
    //     return to.clone().sub(from).normalize().multiplyScalar(distance * pct).add(from);
    // }
    /**
     * create a new Vector3 instance by parameters.
     *
     * @date 2019-01-20
     * @export
     * @param {THREE.Vector3} from
     * @param {THREE.Vector3} to
     * @param {number} alpha
     * @returns {THREE.Vector3}
     */
    function lerpVector3(from, to, alpha) {
        // this.x += ( v.x - this.x ) * alpha;
        // this.y += ( v.y - this.y ) * alpha;
        // this.z += ( v.z - this.z ) * alpha;
        return to.clone().sub(from).multiplyScalar(alpha).add(from);
    }
    Util.lerpVector3 = lerpVector3;
    /**
     *
     * @param {THREE.BufferAttribute} bufferAttr The BufferAttribute instance
     * @param {[number, number, number]} vec3 must be number[3]
     * @version 1.0
     * @date 2022/1/19
     * @todo pass Array constructor
     */
    function addVector3To(bufferAttr, vec3) {
        // DEVNOTE: 2022/02/03 WebGL は Float64Array の値を受け取れない？ので、結局ダメ
        const oldVec = bufferAttr.array;
        const newVec = new Float32Array(oldVec.length + 3);
        // const oldVec = bufferAttr.array as Float64Array;
        // const newVec = new Float64Array(oldVec.length + 3);
        let i = 0;
        for (; i < oldVec.length;) {
            newVec[i] = oldVec[i];
            newVec[i + 1] = oldVec[i + 1];
            newVec[i + 2] = oldVec[i + 2];
            i += 3;
        }
        newVec[i] = vec3[0];
        newVec[i + 1] = vec3[1];
        newVec[i + 2] = vec3[2];
        bufferAttr.array = newVec;
        bufferAttr.count += 1;
    }
    Util.addVector3To = addVector3To;
    // DEVNOTE: from: http://gizma.com/easing/
    //   script = ""; document.querySelectorAll("blockquote > pre").forEach(pre => script += pre.textContent);
    /** all functions signature are:
     *
     *   (currentTime: number, startValue: number, changeValue: number, duration: number) => number;
     */
    let Mazh;
    (function (Mazh) {
        /**
         * simple linear tweening - no easing, no acceleration
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function linearTween(t, b, c, d) {
            return c * t / d + b;
        }
        Mazh.linearTween = linearTween;
        ;
        // TODO: 2022/3/9 22:03:32
        // /**
        //  * Overshoots over 1 multiple times - wiggles around 1.
        //  *
        //  * @export
        //  * @param {number} t (t)ime
        //  * @param {number} b (b)ase
        //  * @param {number} c (c)hange
        //  * @param {number} d (d)uration
        //  */
        // // Overshoots over 1 multiple times - wiggles around 1.
        // export function elastic(t: number, b: number, c: number, d: number) {
        //     return t * (33 * t * t * t * t - 106 * t * t * t + 126 * t * t - 67 * t + 15);
        // }
        /**
         * quadratic easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInQuad(t, b, c, d) {
            t /= d;
            return c * t * t + b;
        }
        Mazh.easeInQuad = easeInQuad;
        ;
        /**
         * quadratic easing out - decelerating to zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutQuad(t, b, c, d) {
            t /= d;
            return -c * t * (t - 2) + b;
        }
        Mazh.easeOutQuad = easeOutQuad;
        ;
        /**
         * quadratic easing in/out - acceleration until halfway, then deceleration
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutQuad(t, b, c, d) {
            t /= d / 2;
            if (t < 1)
                return c / 2 * t * t + b;
            t--;
            return -c / 2 * (t * (t - 2) - 1) + b;
        }
        Mazh.easeInOutQuad = easeInOutQuad;
        ;
        /**
         * cubic easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInCubic(t, b, c, d) {
            t /= d;
            return c * t * t * t + b;
        }
        Mazh.easeInCubic = easeInCubic;
        ;
        /**
         * cubic easing out - decelerating to zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutCubic(t, b, c, d) {
            t /= d;
            t--;
            return c * (t * t * t + 1) + b;
        }
        Mazh.easeOutCubic = easeOutCubic;
        ;
        /**
         * cubic easing in/out - acceleration until halfway, then deceleration
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutCubic(t, b, c, d) {
            t /= d / 2;
            if (t < 1)
                return c / 2 * t * t * t + b;
            t -= 2;
            return c / 2 * (t * t * t + 2) + b;
        }
        Mazh.easeInOutCubic = easeInOutCubic;
        ;
        /**
         * quartic easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInQuart(t, b, c, d) {
            t /= d;
            return c * t * t * t * t + b;
        }
        Mazh.easeInQuart = easeInQuart;
        ;
        /**
         * quartic easing out - decelerating to zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutQuart(t, b, c, d) {
            t /= d;
            t--;
            return -c * (t * t * t * t - 1) + b;
        }
        Mazh.easeOutQuart = easeOutQuart;
        ;
        /**
         * quartic easing in/out - acceleration until halfway, then deceleration
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutQuart(t, b, c, d) {
            t /= d / 2;
            if (t < 1)
                return c / 2 * t * t * t * t + b;
            t -= 2;
            return -c / 2 * (t * t * t * t - 2) + b;
        }
        Mazh.easeInOutQuart = easeInOutQuart;
        ;
        /**
         * quintic easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInQuint(t, b, c, d) {
            t /= d;
            return c * t * t * t * t * t + b;
        }
        Mazh.easeInQuint = easeInQuint;
        ;
        /**
         * quintic easing out - decelerating to zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutQuint(t, b, c, d) {
            t /= d;
            t--;
            return c * (t * t * t * t * t + 1) + b;
        }
        Mazh.easeOutQuint = easeOutQuint;
        ;
        /**
         * quintic easing in/out - acceleration until halfway, then deceleration
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutQuint(t, b, c, d) {
            t /= d / 2;
            if (t < 1)
                return c / 2 * t * t * t * t * t + b;
            t -= 2;
            return c / 2 * (t * t * t * t * t + 2) + b;
        }
        Mazh.easeInOutQuint = easeInOutQuint;
        ;
        /**
         * sinusoidal easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInSine(t, b, c, d) {
            return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }
        Mazh.easeInSine = easeInSine;
        ;
        /**
         * sinusoidal easing out - decelerating to zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutSine(t, b, c, d) {
            return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }
        Mazh.easeOutSine = easeOutSine;
        ;
        /**
         * sinusoidal easing in/out - accelerating until halfway, then decelerating
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutSine(t, b, c, d) {
            return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }
        Mazh.easeInOutSine = easeInOutSine;
        ;
        /**
         * exponential easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInExpo(t, b, c, d) {
            return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }
        Mazh.easeInExpo = easeInExpo;
        ;
        /**
         *
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutExpo(t, b, c, d) {
            return c * (-Math.pow(2, -10 * t / d) + 1) + b;
        }
        Mazh.easeOutExpo = easeOutExpo;
        ;
        /**
         * exponential easing out - decelerating to zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutExpo(t, b, c, d) {
            t /= d / 2;
            if (t < 1)
                return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
            t--;
            return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }
        Mazh.easeInOutExpo = easeInOutExpo;
        ;
        /**
         * exponential easing in/out - accelerating until halfway, then decelerating
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInCirc(t, b, c, d) {
            t /= d;
            return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }
        Mazh.easeInCirc = easeInCirc;
        ;
        /**
         *
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeOutCirc(t, b, c, d) {
            t /= d;
            t--;
            return c * Math.sqrt(1 - t * t) + b;
        }
        Mazh.easeOutCirc = easeOutCirc;
        ;
        /**
         * circular easing in - accelerating from zero velocity
         *
         * @date 2019-01-11
         * @export
         * @param {number} t (t)ime
         * @param {number} b (b)ase
         * @param {number} c (c)hange
         * @param {number} d (d)uration
         * @returns The value of the position of time delta from b to b + c.
         */
        function easeInOutCirc(t, b, c, d) {
            t /= d / 2;
            if (t < 1)
                return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
            t -= 2;
            return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }
        Mazh.easeInOutCirc = easeInOutCirc;
        ;
    })(Mazh = Util.Mazh || (Util.Mazh = {}));
    /** Mazh function names */
    const MazhFunctions = Object.keys(Mazh);
    function getMazhFunctionNames() {
        return MazhFunctions.slice(0);
    }
    Util.getMazhFunctionNames = getMazhFunctionNames;
    /**
     * choose from: http://gizma.com/easing/
     * ```
    [
    "linearTween",
    "easeInQuad",
    "easeOutQuad",
    "easeInOutQuad",
    "easeInCubic",
    "easeOutCubic",
    "easeInOutCubic",
    "easeInQuart",
    "easeOutQuart",
    "easeInOutQuart",
    "easeInQuint",
    "easeOutQuint",
    "easeInOutQuint",
    "easeInSine",
    "easeOutSine",
    "easeInOutSine",
    "easeInExpo",
    "easeOutExpo",
    "easeInOutExpo",
    "easeInCirc",
    "easeOutCirc",
    "easeInOutCirc"
    ]
```
     * @date 2019-01-11
     * @export
     * @returns {EaseFunction}
     */
    Util.getRandomMazhFunction = () => {
        return Mazh[Util.randomMazhName()]; // as EaseFunction;
    };
    Util.randomMazhName = () => {
        return MazhFunctions[Math.floor(Math.random() * MazhFunctions.length)];
    };
})(Util || (Util = {}));
export default Util;
