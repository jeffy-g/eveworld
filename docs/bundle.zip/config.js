/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2018 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
export const WorldConfig={
/** for debug */
helperMode:!1,
/** defulat: false */
showAxes:!1,
/** defulat: false */
showGrid:!1,
/** default: 0.15 ly */
"Ray threshold(LY)":.25,
/** default: 0.85 ly */
"system size(LY)":.85,
/** default: 5 */
"system size(fixed)":7,
/** default: 0.25 ly */
"hunter radius(LY)":.25,"hunter opacity":.4,
/** toggle wireframe. */
"hunter use wireframe":!1,
/** change sphere division. */
"hunter sphere division":16,
/** system close up distance. (unit of "LY". */
"closeUp to":10,fov:50,resetCamera:()=>{},updateRegionColors:()=>{EVEWorld.updateRegionsColor()},"Find system":"",worldConfig:{
/** default: 0.01 */
stepOfRotateY:.01,
/** default: 0. (min: -300, max 300) * UniverseUnit.LY */
rotateRadiusAdjust:0,moveCamera:!1,visible:!0,
/**
         * default Camera Animate Duration
         */
dcad:4},"Apply texture":!0,transparent:!1,opacity:1,colorStop0:.21,colorStop1:.3,colorStop2:.54,blending:THREE.AdditiveBlending,depthFunc:THREE.AlwaysDepth,regionVisibility:{"Region name":!0,"Text scale":.8,universe:{},wormhole:{ALL:!0}},systemHunt:"tick",systemCloseUp:"fadein",closeUpEaseFanction:"easeOutSine",effectVolume:.5,
/** use 30fps? */
reduceFps:!1,
/** default: window.devicePixelRatio */
PixelRatio:window.devicePixelRatio};