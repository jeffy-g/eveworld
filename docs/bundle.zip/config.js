/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2018 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
//<reference types="three"/>
// import * as THREE from "three";
export const WorldConfig = {
    /** for debug */
    helperMode: false,
    /** defulat: false */
    showAxes: false,
    // axesLineWidth: 1,
    /** defulat: false */
    showGrid: false,
    /** default: 0.15 ly */
    "Ray threshold(LY)": 0.25,
    /** default: 0.85 ly */
    "system size(LY)": .85,
    /** default: 5 */
    "system size(fixed)": 7,
    /** default: 0.25 ly */
    "hunter radius(LY)": 0.25,
    "hunter opacity": 0.4,
    /** toggle wireframe. */
    "hunter use wireframe": false,
    /** change sphere division. */
    "hunter sphere division": 16,
    /** system close up distance. (unit of "LY". */
    "closeUp to": 10,
    fov: 50,
    resetCamera: () => { },
    updateRegionColors: () => {
        EVEWorld.updateRegionsColor();
    },
    "Find system": "",
    // - - - World Rotation - - -
    worldConfig: {
        /** default: 0.01 */
        stepOfRotateY: 0.01,
        /** default: 0. (min: -300, max 300) * UniverseUnit.LY */
        rotateRadiusAdjust: 0,
        moveCamera: false,
        visible: true,
        /**
         * default Camera Animate Duration
         */
        dcad: 4,
        // unused...
        // intensity: 1,
    },
    // - - - Material config - - -
    "Apply texture": true,
    transparent: false,
    opacity: 1,
    // 1/17/2019, 9:53:07 PM - texture config
    colorStop0: .21,
    colorStop1: .3,
    colorStop2: .54,
    // DEVNOTE: When "AdditiveBlending" is applied, opacity is applied regardless of the value of "transparent".
    blending: THREE.AdditiveBlending,
    depthFunc: THREE.AlwaysDepth,
    // - - - Region Visibility - - -
    regionVisibility: {
        "Region name": true,
        "Text scale": 0.8,
        universe: {},
        wormhole: {
            ALL: true,
        },
    },
    // 1/16/2019, 8:11:36 PM sound effect etc.
    systemHunt: "tick",
    systemCloseUp: "fadein",
    // 
    closeUpEaseFanction: "easeOutSine",
    effectVolume: 0.5,
    // webgl
    /** use 30fps? */
    reduceFps: false,
    /** default: window.devicePixelRatio */
    PixelRatio: window.devicePixelRatio,
    // DEVNOTE: 1/23/2019, 2:22:05 AM - https://discourse.threejs.org/t/whats-this-about-gammafactor/4264
    // DEVNOTE: gammaFactor already removed at v 0.136
    // gammaFactor: 2.2,
    // // DEVNOTE: 2019/12/17 10:35:52 - removed at r112
    // gammaInput: true,
    // // DEVNOTE: 2019/12/17 10:35:52 - removed at r112
    // gammaOutput: true,
};
