/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2019 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                             imports.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// import * as THREE from "three";
// import * as dat from "dat.gui";
import UniverseUnit from "eveworld/universe-unit.js";
import Util from "eveworld/util.js";
import { WorldConfig } from "eveworld/config.js";
import View from "eveworld/view.js";
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                         constants, types
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                      module vars, functions.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
function forEachRegioins(handler) {
    const regions = EVEWorld.getRegionObjects();
    for (const region of Object.values(regions)) {
        handler(region);
    }
}
function forEachRegioinsMaterial(handler) {
    const regions = EVEWorld.getRegionObjects();
    for (const region of Object.values(regions)) {
        handler(region.material);
    }
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                    class or namespace declare.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
var ConfigUI;
(function (ConfigUI) {
    // function _checkHelperExists(name: string): void {
    //     if (ThreeComponents[name] === void 0) {
    //         View.createHelpers();
    //     }
    // }
    /**
     * MUST calls after region object created.
     * @param hunterName
     */
    function initGUI(hunterName) {
        const { camera, raycaster, scene, 
        // light,
        webGLRenderer, } = View.getTHREERelated();
        const gui = new lil.GUI({
            // width: "12vw",
            closeOnTop: true,
            load: {
                preset: "Default", close: false,
                remembered: {
                    Default: {
                        0: Util.deepClone(WorldConfig)
                    }
                }
            }
        });
        // TODO: regions
        // @ts-ignore 
        gui.load(WorldConfig);
        // gui.remember(WorldConfig);
        // TODO: 1/16/2019, 6:52:17 PM - divide each type kind.
        let regionName;
        gui.add(WorldConfig, "helperMode").onChange((value) => {
            // _checkHelperExists("cameraHelper");
            // DEVNOTE: 2022/02/12 revert
            // if (value && regionName.getValue()) {
            //     regionName.setValue(!value);
            // }
            ThreeComponents.cameraHelper.visible = value;
        });
        // const axes = ThreeComponents.axes;
        gui.add(WorldConfig, "showAxes").onChange((value) => {
            // _checkHelperExists("axes");
            ThreeComponents.axes.visible = value;
        });
        // gui.add({ axesLineWidth: UniverseUnit.ly(1) }, "axesLineWidth").min(UniverseUnit.ly(0.1)).max(UniverseUnit.ly(20)).step(UniverseUnit.ly(0.01)).onChange((value: number) => {
        //     // _checkHelperExists("axes");
        //     const mat = (axes.material as THREE.LineBasicMaterial);
        //     mat.linewidth = value;
        //     mat.needsUpdate = true;
        // });
        gui.add(WorldConfig, "showGrid").onChange((value) => {
            // _checkHelperExists("gridHelper");
            ThreeComponents.gridHelper.visible = value;
        });
        // 
        WorldConfig.resetCamera = () => {
            EVEWorld.defaultCameraPosition();
        };
        gui.add(WorldConfig, "resetCamera");
        // update all region color.
        gui.add(WorldConfig, "updateRegionColors");
        const at = new THREE.Vector3();
        // TODO: refactoring for visuals
        gui.add(WorldConfig, "Find system").onChange((value) => {
            const sys = EVEWorld.findSystemByName(value);
            if (sys) {
                console.log(sys);
                EVEWorld.fireSystemHunted(sys);
                EVEWorld.lookAt(at.set(...sys.vec));
            }
        });
        // - - - World Config #2 - - -
        const wconfig1 = gui.addFolder("World Config#1").close();
        {
            function _applyParamsToPS(method, params) {
                const ps = scene.getObjectByName(hunterName);
                // @ts-ignore 
                ps && ps[method](...params);
            }
            // 1/14/2019, 10:01:15 PM
            wconfig1.add(WorldConfig, "Ray threshold(LY)").min(0.001).max(1).step(0.001).onChange(function (value) {
                // DEVNOTE: do not use "au" unit!. because the canvas element crash.
                raycaster.params.Points.threshold = value * UniverseUnit.LY;
            });
            wconfig1.add(WorldConfig, "system size(fixed)").min(1).max(50).step(0.1).onChange(function (value) {
                // DEVNOTE: do not use "au" unit!. because the canvas element crash.
                EVEWorld.setSystemSize(value);
            });
            wconfig1.add(WorldConfig, "system size(LY)").min(0.25).max(3).step(0.01).onChange(function (value) {
                // DEVNOTE: do not use "au" unit!. because the canvas element crash.
                EVEWorld.setSystemSize(value, true);
            });
            const hunterRadius = wconfig1.add(WorldConfig, "hunter radius(LY)").min(0.01).max(3).step(0.01).onChange(function (value) {
                // const ps = scene.getObjectByName(hunterName) as PointerSphere;
                // ps && ps.setRadius(value * UniverseUnit.LY);
                _applyParamsToPS("setRadius", [value * UniverseUnit.LY]);
            });
            wconfig1.add(WorldConfig, "hunter opacity").min(0).max(1).step(0.01).onChange(function (value) {
                _applyParamsToPS("setOpacity", [value]);
            });
            wconfig1.add(WorldConfig, "hunter sphere division").min(3).max(128).step(1).onChange(function (value) {
                _applyParamsToPS("setRadius", [hunterRadius.getValue() * UniverseUnit.LY, value]);
            });
            wconfig1.add(WorldConfig, "hunter use wireframe").onChange(function (value) {
                _applyParamsToPS("useWireFrame", [value]);
            });
            // - - - system close up distance
            wconfig1.add(WorldConfig, "closeUp to").min(0.5).max(50).step(0.01);
            wconfig1.add(WorldConfig, "fov").min(30).max(180).step(1).onChange(function (value) {
                // EVEWorld.setFOV(value);
                camera.fov = value;
                camera.updateProjectionMatrix();
            });
        }
        // - - - World Config #2 - - -
        const wconfig2 = gui.addFolder("World Config#2");
        {
            const _worldConfig = WorldConfig.worldConfig;
            wconfig2.add(_worldConfig, "visible").onChange((value) => {
                const eveWorldCanvas = $query(".eve-world");
                if (eveWorldCanvas) {
                    eveWorldCanvas.style.opacity = +value + "";
                }
            });
            // DEVNOTE: It does not seem necessary for this project.
            // wconfig.add(_worldConfig, "intensity").min(0).max(10).step(0.01).onChange((value: number) => {
            //     light.intensity = value;
            // });
            wconfig2.add(_worldConfig, "moveCamera");
            wconfig2.add(_worldConfig, "stepOfRotateY", -20, 20, 0.001);
            wconfig2.add(_worldConfig, "rotateRadiusAdjust", -300, 300, 0.1);
            // DEVNOTE: do not exec this code.
            // .onChange(function (value: number) {
            //     this.object[this.property] *= UniverseUnit.LY;
            // });
            wconfig2.add(_worldConfig, "dcad", 1, 20, 0.1);
        }
        wconfig2.open();
        // - - - Material config - - -
        const materialFolder = gui.addFolder("Material config").close();
        {
            // Apply texture?
            materialFolder.add(WorldConfig, "Apply texture").onChange((value) => {
                const texture = value ? EVEWorld.getSystemTexture() : null;
                forEachRegioinsMaterial(m => {
                    m.map = texture;
                    m.needsUpdate = true;
                });
            });
            // transparent 
            materialFolder.add(WorldConfig, "transparent").onChange((value) => {
                forEachRegioinsMaterial(m => {
                    m.transparent = value;
                    m.needsUpdate = true;
                });
            });
            materialFolder.add(WorldConfig, "opacity").min(0).max(1).step(0.001).onChange((value) => {
                forEachRegioinsMaterial(m => {
                    m.opacity = value;
                    m.needsUpdate = true;
                });
            });
            // 1/17/2019, 9:53:20 PM - change texture dynamically.
            ["colorStop0", "colorStop1", "colorStop2"].forEach(property => {
                materialFolder.add(WorldConfig, property).min(0).max(1).step(0.01).onChange(() => {
                    updateSystemTextureDynamically();
                });
            });
            materialFolder.add(WorldConfig, "blending", {
                NoBlending: THREE.NoBlending,
                NormalBlending: THREE.NormalBlending,
                AdditiveBlending: THREE.AdditiveBlending,
                SubtractiveBlending: THREE.SubtractiveBlending,
                MultiplyBlending: THREE.MultiplyBlending,
                CustomBlending: THREE.CustomBlending,
            }).onChange((value) => {
                // typeof value === "string" && (value = Number.parseInt(value));
                forEachRegioinsMaterial(m => {
                    // DEVNOTE: "+" operator using instead of "parseInt".
                    m.blending = +value;
                    m.needsUpdate = true;
                });
            });
            materialFolder.add(WorldConfig, "depthFunc", {
                NeverDepth: THREE.NeverDepth,
                AlwaysDepth: THREE.AlwaysDepth,
                LessDepth: THREE.LessDepth,
                LessEqualDepth: THREE.LessEqualDepth,
                EqualDepth: THREE.EqualDepth,
                GreaterEqualDepth: THREE.GreaterEqualDepth,
                GreaterDepth: THREE.GreaterDepth,
                NotEqualDepth: THREE.NotEqualDepth,
            }).onChange((value) => {
                forEachRegioinsMaterial(m => {
                    // DEVNOTE: "+" operator using instead of "parseInt".
                    m.depthFunc = +value;
                    m.needsUpdate = true;
                });
            });
        }
        // - - - Material config - - -
        // - - - Region Visibility - - -
        const regionFolder = gui.addFolder("Region Visibility").close();
        {
            const regions = EVEWorld.getRegionObjects();
            const regionNames = Object.keys(regions).sort();
            const regionVisibility = WorldConfig.regionVisibility;
            // show, hide region name. 
            regionName = regionFolder.add(regionVisibility, "Region name").onChange(function (value) {
                // BooleanController
                // console.log(this);
                forEachRegioins(region => {
                    // const label = getCSS2DObjectFrom(region);
                    // label.element.style.opacity = +value + "";
                    setLableVisibility(region, value);
                });
            });
            // text scale.
            regionFolder.add(regionVisibility, "Text scale").min(0).max(10).step(0.01).onChange(function (value) {
                forEachRegioins(region => {
                    // const label = getCSS2DObjectFrom(region);
                    const label = getCSS2DObjectFrom(region);
                    label && (label.scale2d = value);
                });
            });
            // show, hide region.
            const re_wh_region = /\w-\w\d{5}/;
            const wormhole = regionFolder.addFolder("wormhole region").close();
            const universe = regionFolder.addFolder("universe region").close();
            const whContollers = [];
            wormhole.add(regionVisibility.wormhole, "ALL").onChange((value) => {
                for (const ctrl of whContollers) {
                    ctrl.setValue(value);
                }
            });
            for (const name of regionNames) {
                const isWormHole = re_wh_region.test(name);
                const regionKind = isWormHole ? regionVisibility.wormhole : regionVisibility.universe;
                // @ts-ignore 
                regionKind[name] = true;
                const ctrl = (isWormHole ? wormhole : universe).add(regionKind, name).onChange((value) => {
                    const region = regions[name];
                    if (region) {
                        region.visible = value;
                        setLableVisibility(region, value);
                    }
                });
                isWormHole && whContollers.push(ctrl);
            }
        }
        // regionFolder.open();
        const miscFolder = gui.addFolder("Effect Sound").close();
        // - - - effect sound setting.
        {
            const tagList = AppEffects.getDefaultTagList();
            miscFolder.add(WorldConfig, "systemHunt", tagList).onChange((value) => {
                ConfigUI.TagSystemHunt = value;
            }).setValue(ConfigUI.TagSystemHunt);
            miscFolder.add(WorldConfig, "systemCloseUp", tagList).onChange((value) => {
                ConfigUI.TagSystemCloseUp = value;
            }).setValue(ConfigUI.TagSystemCloseUp);
            // system close up animation usin ease.
            miscFolder.add(WorldConfig, "closeUpEaseFanction", Util.getMazhFunctionNames());
            miscFolder.add(WorldConfig, "effectVolume").min(0).max(1).step(0.01).onChange(function (value) {
                const tags = tagList;
                for (const tag of tags) {
                    AppEffects.setVolume(tag, value);
                }
            }).setValue(WorldConfig.effectVolume);
        }
        // - - - Render setting.
        const renderFolder = gui.addFolder("Render config").close();
        // reduceFps
        renderFolder.add(WorldConfig, "reduceFps");
        // PixelRatio
        renderFolder.add(WorldConfig, "PixelRatio").min(0.1).max(3).step(0.1).onChange(function (value) {
            webGLRenderer.setPixelRatio(value);
        });
        // gammaFactor
        // DEVNOTE: gammaFactor already removed at v 0.136
        // renderFolder.add(WorldConfig, "gammaFactor").min(0).max(10).step(0.01).onChange(function (value: number) {
        //     webGLRenderer.gammaFactor = value;
        // });
        // // DEVNOTE: 2019/12/17 10:35:52 - removed at r112
        // // gammaInput
        // renderFolder.add(WorldConfig, "gammaInput").onChange(function (value: boolean) {
        //     webGLRenderer.gammaInput = value;
        // });
        // // DEVNOTE: 2019/12/17 10:35:52 - removed at r112
        // // gammaOutput
        // renderFolder.add(WorldConfig, "gammaOutput").onChange(function (value: boolean) {
        //     webGLRenderer.gammaOutput = value;
        // });
    }
    ConfigUI.initGUI = initGUI;
    // - - - utility functions
    function updateSystemTextureDynamically() {
        const texture = EVEWorld.getSystemTexture(true);
        forEachRegioinsMaterial(m => {
            m.map = texture;
            m.needsUpdate = true;
        });
    }
    function setLableVisibility(region, visible) {
        const label = getCSS2DObjectFrom(region);
        if (label) {
            label.element.style.opacity = +visible + "";
        }
    }
    function getCSS2DObjectFrom(region) {
        return region.getObjectByProperty("type", "CSS2DObject");
    }
    /**
     * system hunted effect.
     */
    ConfigUI.TagSystemHunt = "tick";
    /**
     * system close up effect.
     */
    ConfigUI.TagSystemCloseUp = "fadein";
    /**
     * add a user friendly description.
     *
     * @date 2019-01-15
     * @export
     */
    function addAnnotationToGui() {
        // $queryAll<HTMLElement>("li.cr.boolean,li.cr.number,li.cr.function").forEach(li => {
        $queryAll(".controller.boolean,.controller.number,.controller.function,.controller.string").forEach(div => {
            let explain = "";
            switch (div.textContent) {
                case "helperMode":
                    explain = "Switch browse mode and helper mode.";
                    break;
                case "showAxes":
                    explain = "Axes line length: 50LY";
                    break;
                case "showGrid":
                    explain = "Grid distance: 4LY";
                    break;
                case "resetCamera":
                    explain = "Return to default camera position then look at world center";
                    break;
                case "updateRegionColors":
                    explain = "Update system fill color randomly";
                    break;
                case "Find system":
                    explain = "find system by name (ignore case)";
                    break;
                case "dcad":
                    explain = "(d)efault (C)amera (A)nimate (D)uration";
                    break;
            }
            explain && (div.title = explain);
        });
    }
    ConfigUI.addAnnotationToGui = addAnnotationToGui;
})(ConfigUI || (ConfigUI = {}));
export default ConfigUI;
