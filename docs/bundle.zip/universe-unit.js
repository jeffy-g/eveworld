/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2018 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
// DEVNOTE: webpack replace: https://regex101.com/r/SbHKOo/1
var UniverseUnit;
(function (UniverseUnit) {
    /**
     * Astronomical unit
     *
     * 1AU = 149,597,870,700 m
     */
    UniverseUnit.AU = 149597870700; // or 1.495978707e11
    /**
     * 1LY = 9,460,730,472,580,800 m
     *
     * NOTE: 1 LY = 63241.07708426628 AU
     */
    UniverseUnit.LY = 9460730472580800; // 9,460,730,472,580,800 m
    /**
     * multiply by light-year
     *
     * NOTE: ly = 9,460,730,472,580,800 m
     *
     * @param n unit of light-year
     */
    function ly(n) {
        return n * UniverseUnit.LY;
    }
    UniverseUnit.ly = ly;
    /**
     * convert to light-year unit.
     *
     * NOTE: ly = 9,460,730,472,580,800 m
     *
     * @param n unit of normal
     */
    function toLY(n) {
        typeof n === "string" && (n = parseFloat(n));
        return n / UniverseUnit.LY;
    }
    UniverseUnit.toLY = toLY;
    /**
     * multiply by Astronomical unit
     *
     * NOTE: 1AU = 149,597,870,700 m
     *
     * @param n unit of Astronomical unit
     */
    function au(n) {
        return n * UniverseUnit.AU;
    }
    UniverseUnit.au = au;
    /**
     * convert to Astronomical unit.
     *
     * NOTE: 1AU = 149,597,870,700 m
     *
     * @param n unit of normal
     */
    function toAU(n) {
        typeof n === "string" && (n = parseFloat(n));
        return n / UniverseUnit.AU;
    }
    UniverseUnit.toAU = toAU;
})(UniverseUnit || (UniverseUnit = {}));
export default UniverseUnit;
