/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2018 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
var UniverseUnit;!function(n){
/**
     * Astronomical unit
     *
     * 1AU = 149,597,870,700 m
     */
n.AU=149597870700,
/**
     * 1LY = 9,460,730,472,580,800 m
     *
     * NOTE: 1 LY = 63241.07708426628 AU
     */
n.LY=9460730472580800,n.ly=
/**
     * multiply by light-year
     *
     * NOTE: ly = 9,460,730,472,580,800 m
     *
     * @param n unit of light-year
     */
function(t){return t*n.LY},n.toLY=
/**
     * convert to light-year unit.
     *
     * NOTE: ly = 9,460,730,472,580,800 m
     *
     * @param n unit of normal
     */
function(t){return"string"==typeof t&&(t=parseFloat(t)),t/n.LY},n.au=
/**
     * multiply by Astronomical unit
     *
     * NOTE: 1AU = 149,597,870,700 m
     *
     * @param n unit of Astronomical unit
     */
function(t){return t*n.AU},n.toAU=
/**
     * convert to Astronomical unit.
     *
     * NOTE: 1AU = 149,597,870,700 m
     *
     * @param n unit of normal
     */
function(t){return"string"==typeof t&&(t=parseFloat(t)),t/n.AU}}(UniverseUnit||(UniverseUnit={}));export default UniverseUnit;