/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2019 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                         module vars, functions.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// 
// - - - define global functions
// 
(function (g) {
    g["$dom"] = function (id) {
        return document.getElementById(id);
    };
    /**
     * check the value is "null" or "undefined".
     * @param subject
     */
    g["$isBadValue"] = function (subject) { return subject === null || subject === void 0; };
    /**
     * if context is string then must be "#elementId" or ".class_name" selector.
     * @param selector
     * @param context when
     */
    g["$queryAll"] = function $queryAll(selector, context) {
        return _qbase(selector, context, "querySelectorAll");
    };
    // 2017/05/12 22:11:09
    /**
     * if context is string then must be "#elementId" or ".class_name" selector.
     * @param selector
     * @param context
     */
    g["$query"] = function $query(selector, context) {
        return _qbase(selector, context, "querySelector");
    };
    function _qbase(selector, context, method) {
        if ($isBadValue(context)) {
            context = document;
        }
        // // DEVNOTE: context is selector string?
        // else if (typeof context === "string") {
        //     context = _qbase<Element | Document>(context, document);
        // }
        // @ts-ignore typescript cannot detect function signature.
        return context[method](selector);
    }
    g["$consumeEvent"] = function consumeEvent(e, immediate = false) {
        const method = immediate ? "stopImmediatePropagation" : "stopPropagation";
        e[method]();
        e.preventDefault();
    };
    function _emitDefer(time = 33, this_p = null, ...args) {
        this.__timeoutId__ = window.setTimeout(() => {
            // delete this.__timeoutId__;
            this.__timeoutId__ = void 0;
            this.apply(this_p, args);
        }, time);
    }
    const _cancelPreviously = function () {
        const tid = this.__timeoutId__;
        // console.log(tid);
        tid && (window.clearTimeout(tid),
            console.log("Function::cancelPreviously - timer canceled, timer id:", tid),
            this.__timeoutId__ = void 0
        // delete this.__timeoutId__
        );
    };
    // default is undefined
    Function.prototype.__timeoutId__ = void 0;
    /**
     * however, this contenxt is null.
     * NOTE: when apply to arrow function, "this_p" parameter is ignored.
     *
     * TODO: DEFINE WITH APPROPRIATE SOURCE FILE.
     */
    Function.prototype.emitDefer = _emitDefer;
    /**
     * can cancel previous timer if scheduled by "emitDefer".
     */
    // 11/6/2018, 12:24:59 AM
    Function.prototype.cancelPreviously = _cancelPreviously;
})(window);
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                       class or namespace declare.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
export default void 0;
