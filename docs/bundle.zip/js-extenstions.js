/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2019 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
!function(t){function e(t,e,o){return $isBadValue(e)&&(e=document),e[o](t)}t.$dom=function(t){return document.getElementById(t)},
/**
     * check the value is "null" or "undefined".
     * @param subject
     */
t.$isBadValue=function(t){return null==t},
/**
     * if context is string then must be "#elementId" or ".class_name" selector.
     * @param selector
     * @param context when
     */
t.$queryAll=function(t,o){return e(t,o,"querySelectorAll")},
/**
     * if context is string then must be "#elementId" or ".class_name" selector.
     * @param selector
     * @param context
     */
t.$query=function(t,o){return e(t,o,"querySelector")},t.$consumeEvent=function(t,e=!1){t[e?"stopImmediatePropagation":"stopPropagation"](),t.preventDefault()};Function.prototype.__timeoutId__=void 0,
/**
     * however, this contenxt is null.
     * NOTE: when apply to arrow function, "this_p" parameter is ignored.
     *
     * TODO: DEFINE WITH APPROPRIATE SOURCE FILE.
     */
Function.prototype.emitDefer=function(t=33,e=null,...o){this.__timeoutId__=window.setTimeout((()=>{this.__timeoutId__=void 0,this.apply(e,o)}),t)},
/**
     * can cancel previous timer if scheduled by "emitDefer".
     */
Function.prototype.cancelPreviously=function(){const t=this.__timeoutId__;t&&(window.clearTimeout(t),console.log("Function::cancelPreviously - timer canceled, timer id:",t),this.__timeoutId__=void 0)}}(window);export default void 0;