/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2018 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
// import * as THREE from "three";
const regionMap = {
    "10000001": "Derelik",
    "10000002": "The Forge",
    "10000003": "Vale of the Silent",
    "10000004": "UUA-F4",
    "10000005": "Detorid",
    "10000006": "Wicked Creek",
    "10000007": "Cache",
    "10000008": "Scalding Pass",
    "10000009": "Insmother",
    "10000010": "Tribute",
    "10000011": "Great Wildlands",
    "10000012": "Curse",
    "10000013": "Malpais",
    "10000014": "Catch",
    "10000015": "Venal",
    "10000016": "Lonetrek",
    "10000017": "J7HZ-F",
    "10000018": "The Spire",
    "10000019": "A821-A",
    "10000020": "Tash-Murkon",
    "10000021": "Outer Passage",
    "10000022": "Stain",
    "10000023": "Pure Blind",
    "10000025": "Immensea",
    "10000027": "Etherium Reach",
    "10000028": "Molden Heath",
    "10000029": "Geminate",
    "10000030": "Heimatar",
    "10000031": "Impass",
    "10000032": "Sinq Laison",
    "10000033": "The Citadel",
    "10000034": "The Kalevala Expanse",
    "10000035": "Deklein",
    "10000036": "Devoid",
    "10000037": "Everyshore",
    "10000038": "The Bleak Lands",
    "10000039": "Esoteria",
    "10000040": "Oasa",
    "10000041": "Syndicate",
    "10000042": "Metropolis",
    "10000043": "Domain",
    "10000044": "Solitude",
    "10000045": "Tenal",
    "10000046": "Fade",
    "10000047": "Providence",
    "10000048": "Placid",
    "10000049": "Khanid",
    "10000050": "Querious",
    "10000051": "Cloud Ring",
    "10000052": "Kador",
    "10000053": "Cobalt Edge",
    "10000054": "Aridia",
    "10000055": "Branch",
    "10000056": "Feythabolis",
    "10000057": "Outer Ring",
    "10000058": "Fountain",
    "10000059": "Paragon Soul",
    "10000060": "Delve",
    "10000061": "Tenerifis",
    "10000062": "Omist",
    "10000063": "Period Basis",
    "10000064": "Essence",
    "10000065": "Kor-Azor",
    "10000066": "Perrigen Falls",
    "10000067": "Genesis",
    "10000068": "Verge Vendor",
    "10000069": "Black Rise",
    "10000070": "Pochven",
    "11000001": "A-R00001",
    "11000002": "A-R00002",
    "11000003": "A-R00003",
    "11000004": "B-R00004",
    "11000005": "B-R00005",
    "11000006": "B-R00006",
    "11000007": "B-R00007",
    "11000008": "B-R00008",
    "11000009": "C-R00009",
    "11000010": "C-R00010",
    "11000011": "C-R00011",
    "11000012": "C-R00012",
    "11000013": "C-R00013",
    "11000014": "C-R00014",
    "11000015": "C-R00015",
    "11000016": "D-R00016",
    "11000017": "D-R00017",
    "11000018": "D-R00018",
    "11000019": "D-R00019",
    "11000020": "D-R00020",
    "11000021": "D-R00021",
    "11000022": "D-R00022",
    "11000023": "D-R00023",
    "11000024": "E-R00024",
    "11000025": "E-R00025",
    "11000026": "E-R00026",
    "11000027": "E-R00027",
    "11000028": "E-R00028",
    "11000029": "E-R00029",
    "11000030": "F-R00030",
    "11000031": "G-R00031",
    "11000032": "H-R00032",
    "11000033": "K-R00033",
    "12000001": "ADR01",
    "12000002": "ADR02",
    "12000003": "ADR03",
    "12000004": "ADR04",
    "12000005": "ADR05",
    "13000001": "PR-01",
    "14000001": "VR-01",
    "14000002": "VR-02",
    "14000003": "VR-03",
    "14000004": "VR-04",
    "14000005": "VR-05"
};
export default regionMap;
// /** embed css style. */
// export const EVEWorldStyle = `
// `;
// export const particleUri = "./libs/particlex128.png";
// /** flare.png */
// export const flareData = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAQAAAGudILpAAAACXBIWXMAAAsTAAALEwEAmpwYAAAG
// S0lEQVRIx02UTWwcdxnGf//52Nndmf2YHa83tpN14tiOkwpHTeuEBCUKokgQtUiREL00KqIXLoCg
// AiEhIU6o4oAqJJC4QEV7aVRBKE0qQapEIVLc0pCQrzZ2E8d2/BXv9+7szM7OzJ8Dbshzfd9H7+F5
// fi+QZyeAw99PXpq9OqCUUF/54oEH38TmX84/fnIAVaMM+OA71+cuvl5AWZ/a7iijRXiW2R9+cMRG
// tRhmkr86r5QmW3MygDjlfuvC+SD0+u+/9e6LY2jj3vffmT40u2SMiNDeuKoBBaZoGHJ8DzYA5CgR
// 6AtKDgDNZgffUTaOD9r1y85qHW2YM6OLv2wcm78VuoOrgNx36bt3luN4YemD0x87NsqJO0GuuxKG
// hui1ooxEqyD+Wd03u9qpWd0LS4+SYjfb+fmR+nSiPnT+xep9RJ4MRQw8NmnRBshgM8Ju9rMfOT2N
// nFhXh7BJAyBs8uRJ8ZuB5qQ3njzQfLAt1OaLn55cbNCmhpC5Zvf30fGvht/OHivl03rDezjfrcqb
// /Pnm7OtxC2Vf84X+8fLDXW7GkBk9pZXMXdt1P3Tk0ZNfShCj+UjUtl5Xu3NngwPOUMpqVXsPtaLe
// Ghi6uy+4J4oMkee9r3yYCg4l9wRtIXSrei173fno5eoGEpFHUCBDmlPKS8/fuTE8vnHtcv2PcZsG
// fdoIgBQpBAZpQOLjI2nT57Gy2DgMUaajlTiXsMnyhGwcRplkP74iJ84KuX+UwudpIgqo5MiR5Bep
// vDP0hebcQCeoN+NjIdQA1SSPw0Hl1SnvQP149xl3+GGifOQP1+elj04PtUSB2b3ZEe3l3gu7Tqo7
// 3bwoLywfTIQr9wjxUGvmm/2nU+mX/Ocmpgdz+YwwW63Bp9ZXDlXPtD1AE+alpxfHrol8P22YupRx
// vje4cCUadYfNlQ6gzDz63ZX5VdUREZGUQhiaaYogU87tmXXSgBJzyhooGcneZqfq+3EUh1GI7PmV
// 9bcaAOoIZ3szyUYhCkBLRBCt3nZrcfOp+MvmD7xfdTUPH3PVXXSeqdxwK6mcaS3fzo0Uqpvnv7by
// STpA8/HY18w3b//NPGzmu3XfT6TdC8bVd1f7ON0Oqo7gnWDps0Ne75EeiHbjY+M/9s23P3lPtgAP
// UUDHJkeStwcq2dzk+q1G9WdegzoxVQCVAiXG2csZ7SCyHIm97GYQB+V/YYGggERHJwl06ROiUEN+
// vgBgoaEQo5JEB0BhTlHL+GPrkoUB9F5luC8RRPTpPlEWFTKYqGhkSGKTJY1FFouc2DMWpUYqr2mp
// aeHPVA00DAI00ojHfRQ2oGKhYaFicFicSGfyvWxoRenCmJZYv5dLbhtc+0hvTtimbNyZiSLaSCQt
// YkDksdDJ8j3xDeW3PO+IXdrUQyXYbu/1s2lbCZobhtdZjjfHnf5891Zq7Y3KxdijSw9BixAxQpoM
// Oqf1/FTv2aVoraxMl/cLy0zqaiy6XrvhVoNW1mqude6OBKnl7ofdpVfdNi4+Ki2EHCJPjs1HnYVi
// o9zdkztamFLS24rZhKYIItmLOt1mpboU1TCaD4K75oK14D/4kefSoY9E/VPnzcrISqG9WQx2x5PK
// pMz1Zb6YTSU1VVGEIlShSCFV6bZqC9ZwEEe+2sv5o53LaPgoKEngNamnzZHUkO6YjmmpYdzxXb8X
// RrFEClShCUVoaiLW+sUdA2ODk6WJUwV9qyhqjiQJvGAgrMuGcLUg8BuaJIpDiYwjGcdB4LqtWmvN
// q5nD3jprYpH72qNp+T4eAi1G0uecnK4ls33LTctUdqR2o24VykbOsPRkMhEF1bWN+aCyc6a21Jk3
// 76WXBjrF8tedzxpU/10TO0iSxcDkp6Y9kT7acpbJjBWHF6+LvhSKIrWk4fnW9tBr39dXBuvJhfrc
// j90WHl0UOgibLBo5NE6nBtOf6p1Br9QrBgW9aG9vuFa21/VaUVs09FqyktpIrb9RuRy7W3YXH1EA
// dCw0sigYzIgT6Uw+toePrK82/KFdoVddUj2tY7TajXPdi7JFRJsQsfVehUIOgcTAQpBCR0NwpRQZ
// K6uz8uSU0P5y89exJMSjv2VW6NN+kkaVDAogUEmSQEEi0JHcTDWUwy7EeATESCCkQ/yYRvEkmAZJ
// JAIQTwxixJbBo7d19//6L9g/3fX6AQqvAAAAAElFTkSuQmCC`;
/**
 * which use texture source?
 */
// export const textureSource = flareData;
