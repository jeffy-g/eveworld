/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2018 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
/*
TODO:
 o. detect system by mouse click event.
   -> camera.lookAt DONE: 2022/5/26 23:56:44 already

*/
//<reference path="./types/three-css2drenderer.d.ts"/>
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                             imports.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
import "web/js-extenstions.js";
import "web/tkit-audio.js";
// import * as THREE from "three";
import UniverseUnit from "eveworld/universe-unit.js";
import regionMap from "eveworld/extra-data.js";
// import { regionMap } from "./extra-data.js";
import Util from "eveworld/util.js";
import { WorldConfig } from "eveworld/config.js";
import View, { TitiledSphereMesh } from "eveworld/view.js";
import ConfigUI from "eveworld/config-ui.js";
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                      module vars, functions.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
/** World center Mesh object name */
const WORLD_CENTER_NAME = "EVEWorld";
/** system hunter...? */
const SYSTEM_HUNTER_NAME = "SystemPointerSphere";
/**
 * avoid implicit bug.
 * assign noop function.
 */
window.runEVEWorld = () => { };
var _EVEWorld;
(function (_EVEWorld) {
    let _proxy;
    // /**
    //  * construct from THREE.FontLoader.load event 
    //  */
    // let fontInstance: THREE.Font;
    /**
     * prepare of eve world map draw.
     *
     * initialize atomic level.
     */
    _EVEWorld.init = (proxy) => {
        // // loadFont("./libs/formated-helvetiker_regular.typeface.json").then(font => fontInstance = font);
        // const fontPath = "./libs/formated-helvetiker_regular.typeface.json";
        // new Promise<THREE.Font>(resolve => {
        //     new THREE.FontLoader().load(fontPath, resolve);
        // }).then(font => fontInstance = font);
        _proxy = proxy;
        proxy.init();
    };
    /**
     *
     */
    const regions = {};
    /**
     * get references of region registry.
     */
    _EVEWorld.getRegionObjects = () => {
        return regions;
    };
    // /**
    //  * 
    //  * @param scene dest scene.
    //  * @param params the SystemPrams instance has EVE system parameters.
    //  * @param textSize system name text size. default is 0.4ly. (too big?
    //  */
    // export const addSystemToScene = (scene: THREE.Scene, params: SystemPrams, textSize = UniverseUnit.ly(0.4)) => {
    //     // // const color = 0x006699; lightblue?
    //     // const matLite = new THREE.MeshBasicMaterial({
    //     //     color: params.color,
    //     //     transparent: true,
    //     //     opacity: 0.9,
    //     //     side: THREE.DoubleSide
    //     // });
    //     // // const matDark = new THREE.LineBasicMaterial({
    //     // //     color: color,
    //     // //     side: THREE.DoubleSide
    //     // // });
    //     // const textShapes = fontInstance.generateShapes(params.name, textSize, 1);
    //     // const g = new THREE.ShapeBufferGeometry(textShapes);
    //     // g.computeBoundingBox(); {
    //     //     const bb = g.boundingBox;
    //     //     // const centerX = -0.5 * (bb.max.x - bb.min.x);
    //     //     const centerY = -0.5 * (bb.max.y - bb.min.y);
    //     //     g.translate(0, centerY, 0);
    //     // }
    //     // // make shape ( N.B. edge view not visible )
    //     // const text: THREE.Mesh = new THREE.Mesh( g, matLite ); {
    //     //     const p = params.position;
    //     //     text.position.x = p.x;
    //     //     text.position.y = p.y;
    //     //     text.position.z = p.z + UniverseUnit.ly(0.25);
    //     // }
    //     // scene.add(text);
    //     // 3e14 or radius * 50
    //     addSphere(scene, params);
    // }
    /**
     * lookAt to `region` or major `system`.
     *
     * @param css2d
     */
    const handleCSS2dTextClick = (css2d) => {
        console.log("select CSS2DObject:", css2d);
        // decide lookAt position.
        let at;
        // parent is region group.
        if (css2d.parent instanceof THREE.Points) {
            at = css2d.parent.geometry.boundingSphere.center;
        }
        else { // parent are sphere etc
            at = css2d.parent.position;
        }
        EVEWorld.lookAt(at /* .clone() */);
    };
    /**
     *
     * @param region THREE.Points instance of region points.
     */
    // CHANGES: 1/16/2019, 9:25:16 PM - we added code to avoid duplication of css2d instance and some bug avoidance code.
    const createRegionLabel = (region) => {
        // DEVNOTE: Sometimes, it may not be built.
        if (!region.geometry.boundingSphere) {
            // createRegionLabel.cancelPreviously();
            createRegionLabel.emitDefer(200, null, region);
            return;
        }
        // if (!region.getObjectByProperty("type", "CSS2DObject")) {
        const vec3 = region.geometry.boundingSphere.center;
        const css2d = View.createCSS2DText(region.name, vec3.x, vec3.y, vec3.z, { className: "region", scale: 0.8 });
        bindCSS2DEvent(css2d);
        region.add(css2d);
        // }
    };
    _EVEWorld.createRegionLabels = () => {
        const regions = _EVEWorld.getRegionObjects();
        for (const region of Object.values(regions)) {
            !region.getObjectByProperty("type", "CSS2DObject") && createRegionLabel(region);
            // region.children.length === 0 && createRegionLabel(region);
        }
    };
    // CHANGES: 1/16/2019, 9:28:44 PM - only remove "CSS2dObject" surely.
    _EVEWorld.removeRegionLabels = () => {
        const regions = _EVEWorld.getRegionObjects();
        for (const region of Object.values(regions)) {
            const css2d = region.getObjectByProperty("type", "CSS2DObject");
            css2d && region.remove(css2d);
        }
    };
    /**
     * when params not specified, add 50au radius sphere to world center. (wire frame
     *
     * @param scene dest scene.
     * @param params SystemPrams object. (if need
     */
    _EVEWorld.addSphere = (scene, params) => {
        const wireframe = !params;
        const { color = new THREE.Color(0xfdfdfd), xyz = [0, 0, 0], 
        // position = new THREE.Vector3(),
        radius = UniverseUnit.au(50), name = WORLD_CENTER_NAME, userData = void 0 } = params || {};
        // DEVNOTE: furthermore, adjust it to 50 multiple.
        const furthermore = 50;
        const g = new THREE.SphereBufferGeometry(radius * furthermore, 18, 18);
        // DEVNOTE: need light
        // const m = new THREE.MeshLambertMaterial({ color, wireframe });
        const m = new THREE.MeshBasicMaterial({ color, wireframe });
        const sphere = new THREE.Mesh(g, m);
        sphere.name = name;
        const css2d = View.createCSS2DText(name, 
        // DEVNOTE: Mesh instance are parent. so x or y or z value must be relative to parent center position.
        0, radius * furthermore, 0, { rgba: `rgba(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, 0.85)` });
        bindCSS2DEvent(css2d);
        sphere.position.set(...xyz);
        sphere.add(css2d);
        userData && (sphere.userData = userData);
        scene.add(sphere);
        return sphere;
    };
    let systemTexture = View.createSystemTexture(true);
    /**
     *
     * @param update
     * @returns
     * @todo move to namespace View(?)
     */
    _EVEWorld.getSystemTexture = (update = false) => {
        if (update) {
            systemTexture = View.createSystemTexture(true);
        }
        return systemTexture;
    };
    /**
     * e.g - `EVEWorld.setSystemSize(2)` => `size * UniverseUnit.LY`
     *
     * @param size must not ly unit. (In this processing, the value is handled as ly unit.
     */
    _EVEWorld.setSystemSize = (size, useLY = false) => {
        const regionPoints = Object.values(regions);
        useLY && (size *= UniverseUnit.LY);
        for (const p of regionPoints) {
            const m = p.material;
            m.sizeAttenuation = useLY;
            m.size = size;
            m.needsUpdate = true;
        }
    };
    /**
     * color string must be "#ffddaa".
     *
     * @param color
     */
    _EVEWorld.updateRegionColor = (regionName) => {
        const region = regions[regionName];
        if (region) {
            region.material.color.setHex(Util.randomHexColor());
        }
    };
    /**
     * update region colors randomly.
     */
    _EVEWorld.updateRegionsColor = () => {
        for (const region of Object.values(regions)) {
            const mat = region.material;
            // const mat = (Array.isArray(systmePoints.material) ? systmePoints.material[0]: systmePoints.material) as THREE.PointsMaterial;
            mat.color.setRGB(...Util.randomRGBColor());
            // mat.color.setHex(
            //     Util.randomHexColor()
            // );
        }
    };
    /**
     * @param name the system name
     * @returns {EVESystemCoordinateMinified | undefined}
     * @date 2022/2/6
     * @todo use regex string
     */
    _EVEWorld.findSystemByName = (name, ignoreCase = true) => {
        const points = Object.values(regions);
        if (ignoreCase) {
            name = name.toLocaleLowerCase();
            for (const region of points) {
                const sysCoords = region.userData.systemList;
                for (let index = 0, end = sysCoords.length; index < end;) {
                    const sysCoord = sysCoords[index++];
                    if (name === sysCoord.n.toLocaleLowerCase()) {
                        return sysCoord;
                    }
                }
            }
        }
        else {
            for (const region of points) {
                const sysCoords = region.userData.systemList;
                for (let index = 0, end = sysCoords.length; index < end;) {
                    const sysCoord = sysCoords[index++];
                    if (sysCoord.n === name) {
                        return sysCoord;
                    }
                }
            }
        }
        return void 0;
    };
    /**
     * MUST OVERRIDE at initialize process.
     * @param target The value is copied internally so you can pass the reference as is.
     */
    _EVEWorld.lookAt = (target, lookAtFrom) => {
        return _proxy.lookAt(target, lookAtFrom);
    };
    /**
     *
     */
    _EVEWorld.distanceToLookAt = () => {
        return _proxy.distanceToLookAt();
    };
    /**
     * @param sysData
     * @date 2022/2/8
     */
    function fireSystemHunted(sysData) {
        _proxy.fireSystemHunted(sysData);
    }
    _EVEWorld.fireSystemHunted = fireSystemHunted;
    const CENTER = new THREE.Vector3(0, 1, 0);
    /**  */
    const DEFAULT_CAMERA_DISTANCE = 45;
    /** WorldConfig["system size(LY) * UniverseUnit.LY"] */
    const POINT_SIZE = UniverseUnit.ly(WorldConfig["system size(LY)"]);
    // 2022/1/19 0:17:11
    function bindCSS2DEvent(css2d) {
        css2d.element.onclick = e => {
            handleCSS2dTextClick(css2d);
            $consumeEvent(e);
        };
    }
    /**
     * The state of seeing the origin from the position of (45LY, 45LY, 45LY)
     *
     * @param {THREE.Vector3} [at]
     */
    // export function defaultCameraPosition<C extends THREE.Camera>(camera: C, at: THREE.Vector3 = CENTER): void {
    function defaultCameraPosition(at = CENTER) {
        const ly = UniverseUnit.ly(DEFAULT_CAMERA_DISTANCE);
        this.lookAt(at, new THREE.Vector3(ly, ly, ly));
        // camera.position.set(ly, ly, ly);
    }
    _EVEWorld.defaultCameraPosition = defaultCameraPosition;
    /** cpu に負荷がかかっていると、scene の構築に時間がかかり、 error. */
    const LABEL_WORK_TIMEOUT = 200;
    /**
     * Draw "EVE world" to THREE.Scene instance.
     *
     * @param {THREE.Scene} scene
     * @returns {Promise<void>}
     */
    _EVEWorld.emitWorld = async (scene) => {
        const sizeAttenuation = true;
        // systemGeo = geom;
        const material = new THREE.PointsMaterial({
            size: sizeAttenuation ? POINT_SIZE : WorldConfig["system size(fixed)"],
            /** size attenuation(サイズ減衰): falseを設定すると、カメラからの距離にかかわらずパーティクルが同じ大きさに */
            sizeAttenuation,
            // NoColors(default) FaceColors VertexColors
            // vertexColors: THREE.NoColors,
            // NormalBlending := CustomBlending, AdditiveBlending
            blending: WorldConfig.blending,
            // default: null
            map: systemTexture,
            // default: new Color( 0xffffff );
            // color: WorldConfig.getSystemColorHex(),
            transparent: WorldConfig.transparent,
            opacity: WorldConfig.opacity,
            // alphaTest: 0,
            depthFunc: WorldConfig.depthFunc,
            depthTest: true,
            /** DEVNOTE: 1/16/2019, 12:40:26 AM
             *   depthWrite=true では、z index の前後において、透明である部分が黒く見えてしまう場合あり.
             *    -> blending の設定次第?
             */
            depthWrite: false
        });
        const sysParam = {};
        // secutiry status color.
        const SystemColorMap = {
            Jita: 0x48F0C0,
            Dodixie: 0x48F0C0,
            Amarr: 0x2FEFEF,
            Hek: 0xEFEF00,
            Rens: 0x48F0C0, // 0.9
        };
        // major systems.
        const majorSystems = Object.keys(SystemColorMap);
        // DEVNOTE: 2022/02/07
        //  Major system: THREE.Mesh
        //  region      : THREE.Points (system point in .userData.systemList[])
        for (let idx = 0, len = EVESystemCoordinates.length; idx < len; idx++) {
            const systemCoord = EVESystemCoordinates[idx];
            const xyz = systemCoord.vec;
            // DEVNOTE: EVE online are development on direct X, so coordinate z the value of aixs is reversed (vs webgl
            // let par ticle = new THREE.Vector3(systemCoord.x, systemCoord.y, -systemCoord.z);
            // const systemName = systemCoord.itemName;
            if (majorSystems.includes(systemCoord.n)) {
                sysParam.color = new THREE.Color(SystemColorMap[systemCoord.n]);
                // ge om.colors.push(params.color);
                sysParam.name = systemCoord.n;
                sysParam.xyz = xyz;
                // params.position = par ticle;
                sysParam.radius = systemCoord.r;
                sysParam.userData = systemCoord; /* 1/14/2019, 11:00:13 PM */
                _EVEWorld.addSphere(scene, sysParam);
            }
            else {
                const regionName = regionMap[systemCoord.rid];
                let region = regions[regionName];
                let geom;
                if (region === void 0) {
                    const newMaterial = material.clone();
                    newMaterial.color.setHex(Util.randomHexColor());
                    geom = new THREE.BufferGeometry();
                    regions[regionName] = region = new THREE.Points(geom, newMaterial);
                    // DEVNOTE: use name property.
                    region.name = regionName;
                    region.userData = {
                        systemList: []
                    };
                    scene.add(region);
                }
                else {
                    geom = region.geometry;
                }
                let bufferAttr = geom.getAttribute("position");
                // let isCreated: boolean;
                if (!bufferAttr) {
                    // DEVNOTE: 2022/02/03 WebGL は Float64Array の値を受け取れない？ので、結局ダメ
                    // bufferAttr = new THREE.Float64BufferAttribute(xyz, 3);
                    // DEVNOTE: 2022/02/03 three.min.js:6 THREE.WebGLAttributes: Unsupported data buffer format: Float64Array.
                    // bufferAttr = new THREE.BufferAttribute(
                    //     new Float64Array(xyz), 3
                    // );
                    bufferAttr = new THREE.BufferAttribute(new Float32Array(xyz), 3);
                    bufferAttr.count = 1;
                    geom.setAttribute("position", bufferAttr);
                }
                else {
                    // DEVNOTE: 2022/02/03 WebGL は Float64Array の値を受け取れない？ので、結局ダメ
                    Util.addVector3To(bufferAttr, xyz);
                }
                // DEVNOTE: not need this operation because before render (maybe
                // bufferAttr.needsUpdate = true;
                /* 1/14/2019, 11:00:13 PM */
                region.userData.systemList.push(systemCoord);
            }
        }
        // add region name element.
        window.setTimeout(() => {
            const regions = _EVEWorld.getRegionObjects();
            for (const region of Object.values(regions)) {
                createRegionLabel(region);
            }
        }, LABEL_WORK_TIMEOUT);
    };
})(_EVEWorld || (_EVEWorld = {}));
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                    class or namespace declare.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
INIT: {
    const TIME_TAG = "initEVEWorld";
    /** adjust requestAnimationFrame rate */
    const EASE_DURATION = 60;
    /**
     * create and insert TitiledSphereMesh into `scene`.
     *
     * @date 2019-01-22
     * @param {THREE.Scene} scene
     */
    const createPointerSphere = (scene) => {
        const pointerSphere = new TitiledSphereMesh(UniverseUnit.ly(WorldConfig["hunter radius(LY)"]), WorldConfig["hunter sphere division"], 
        // DEVNOTE: see _eve-colors.scss
        "eve-system-name sstext-after");
        pointerSphere.name = SYSTEM_HUNTER_NAME;
        scene.add(pointerSphere);
    };
    /**
     * use with IEVEWorldProxy.lookAt
     *
     * name: (l)ook (a)t (s)tep (q)ueue
     */
    let lasq = null;
    /** selected system position by mouse event. */
    let huntedPoint = null;
    /**
     *
     */
    class EVEWorldProxy {
        constructor(camera, orbit) {
            this.camera = camera;
            this.orbit = orbit;
            void 0;
        }
        init() {
            const { webGLRenderer, labelRenderer } = View.getTHREERelated();
            const container = $dom("webgl-container");
            // const ss = document.createElement("style");
            // ss.textContent = EVEWorld Style;
            // container.append(ss);
            container.append(webGLRenderer.domElement);
            container.append(labelRenderer.domElement);
        }
        /**
         * **run easing animation of camera movement**.
         *
         * @param at
         * @param lookAtFrom
         */
        lookAt(at, lookAtFrom) {
            if (lasq) {
                return console.log("'lookAt' animation running..."), false;
            }
            const sc = Util.makeEaseContext(this.orbit.target, at, EASE_DURATION >> +WorldConfig.reduceFps);
            if (sc) {
                const isSystemCloseUp = at === huntedPoint;
                const easeFnName = isSystemCloseUp ? WorldConfig.closeUpEaseFanction : Util.randomMazhName();
                const easeFn = Util.Mazh[easeFnName];
                const target = at.clone();
                // enable camera ease animation.
                lasq = {
                    target,
                    step: sc,
                    easeFn,
                    trace: []
                };
                if (isSystemCloseUp) {
                    /* DEVNOTE: 190119 - complete. */
                    // - Close up to arbitrary distance from "at".
                    lasq.lastCameraPosition = Util.arbitraryCoordinatesInLineSeg(this.camera.position, at, UniverseUnit.ly(WorldConfig["closeUp to"]));
                    // - - - same as:
                    // const cpos = this.camera.position;
                    // const pct = 1 - (UniverseUnit.ly(WorldConfig["closeUp to"]) / cpos.distanceTo(at));
                    // lasq.lastCameraPosition = cpos.clone().lerp(at, pct);
                    // - - - Close up to 80% distance to "at".
                    // lasq.lastCameraPosition = this.camera.position.clone().lerp(at, 0.8)
                    // lasq.lastCameraPosition = at.clone().addScalar(UniverseUnit.ly(6)); // **
                }
                else if (lookAtFrom) {
                    lasq.lastCameraPosition = lookAtFrom;
                    // experimental
                    sc.duration = EASE_DURATION * wconfig.dcad >> +WorldConfig.reduceFps;
                }
                // display ease function name
                View.updateEaseFunctionInfo(easeFnName);
                return true;
            }
            else {
                console.info("you are look at same point!");
                return false;
            }
        }
        distanceToLookAt() {
            return this.camera.position.distanceTo(this.orbit.target);
        }
        /**
         * @param sysData
         * @date 2022/2/8
         */
        fireSystemHunted(sysData) {
            const { scene, camera } = View.getTHREERelated();
            console.log(sysData.n);
            const ps = scene.getObjectByName(SYSTEM_HUNTER_NAME);
            const element = ps.setText(sysData.n);
            // DEVNOTE: see _eve-colors.scss
            element.dataset.sstext = Util.normalizeSS(sysData.ss);
            systemData = sysData;
            const target = new THREE.Vector3(...sysData.vec);
            huntedPoint = target;
            ps.position.copy(target);
            (() => {
                // TODO: target is deferred
                View.updateHuntedDistance(camera.position.distanceTo(target));
                // DEVNOTE: 1/19/2019, 9:04:22 PM
                // soulution of:
                //   Since google chrome has changed the policy on automatic playback, audio auto play is rejected with no user action.
                //    -> see: https://stackoverflow.com/questions/50490304/how-to-make-audio-autoplay-on-chrome Solution #1
                //
                //   It can be avoided by specifying "autoplay" for "allow" attribute of "iframe" element. -> index.html
                AppEffects.emit(ConfigUI.TagSystemHunt);
            }).emitDefer(12);
        }
    }
    /** selected system data. */
    let systemData = null;
    /** ease trace: debug use */
    const EASE_TRACE = false;
    const wconfig = WorldConfig.worldConfig;
    /** progress of ease function. */
    let easeTimeDelta = 0;
    /** flag for move camera. */
    let isCameraMvActive = false;
    let rotateRadius; // = UniverseUnit.ly(DEFAULT_CAMERA_DISTANCE);
    /** DEVNOTE: Get the current `horizontal` plain rotation, in degrees. */
    let hpDegree; // = 45;
    /**
     *
     *
     * @date 2019-01-18
     * @param {number} step unit of degree.
     * @param {THREE.Camera} camera target camera of move animation.
     * @param {THREE.OrbitControls} orbit `OrbitControls` controlling the target camera.
     */
    const _rotateCamera = (step, camera, orbit) => {
        hpDegree += step;
        // DEVNOTE: to radians.
        // THREE.Math.radToDeg(radian) radian / Math.PI * 180
        // THREE.Math.degToRad(deg)    deg * Math.PI / 180
        // DEVNOTE: 2020/5/4 1:49:14 - THREE.Math renamed => MathUtils
        const radian = THREE.MathUtils.degToRad(hpDegree);
        const cpos = camera.position;
        const ctrlTarget = orbit.target;
        // DEVNOTE:
        const adjustedRadius = rotateRadius + UniverseUnit.ly(wconfig.rotateRadiusAdjust);
        //   + ctrlTarget.x(or y) - rotate at current lookAt target.
        //   - ctrlTarget.x(or y) - rotate at world center position (0, 0, 0).
        cpos.x = adjustedRadius * Math.sin(radian) + ctrlTarget.x;
        cpos.z = adjustedRadius * Math.cos(radian) + ctrlTarget.z;
        // cpos.y = adjustedRadius * Math.cos(radian / 2);
        // cpos.add(ctrlTarget)
        // look at current target.
        camera.lookAt(ctrlTarget);
    };
    /**
     * must call render before.
     *
     * @date 2019-01-18
     * @param {THREE.Camera} camera
     * @param {THREE.OrbitControls} orbit
     */
    const _updateDegAndRad = (camera, orbit) => {
        // DEVNOTE: Get the current horizontal rotation, in radians.
        hpDegree = THREE.MathUtils.radToDeg(orbit.getAzimuthalAngle());
        //                      + <- camera
        //     C(distance) ^    |
        //             ^        |
        //         ^            | A(y)
        //      ^               |
        // θ ^                  |
        // +--------------------+
        // |<-lookAt   B(x)
        // https://keisan.casio.jp/exec/system/1259903491
        // A × A + B × B = C × C
        //  or C * cosθ
        // [y ** 2](A) + B = [distance ** 2](C hypotenuse)
        // C
        const cc = camera.position.distanceTo(orbit.target) ** 2;
        /* A (need minus orbit.target.y */
        const aa = (camera.position.y - orbit.target.y) ** 2;
        // B
        rotateRadius = Math.sqrt(cc - aa);
        // // like close but different...
        // const tmp = new THREE.Vector3();
        // camera.getWorldDirection(tmp);
        // rotateRadius = camera.position.distanceTo(orbit.target) * Math.cos(tmp.x);
    };
    /**
     * **Camera for Rendering**
     *
     * choose by normal mode or helper mode
     */
    let cam4render;
    const initEVEWorld = async () => {
        const { 
        // axes,
        stats, orbit, orbit2, scene, raycaster, camera, webGLRenderer, labelRenderer, 
        // helpers
        orbitHelper, objectiveCamera, } = View.getTHREERelated();
        // DEVNOTE: 1/18/2019, 1:59:01 PM - implemented IEVEWorldProxy
        EVEWorld.init(new EVEWorldProxy(camera, orbit));
        // normal mode is default
        cam4render = camera;
        // const trackballControls = new THREE.TrackballControls(camera);
        // trackballControls.rotateSpeed = 1.0;
        // trackballControls.zoomSpeed = 2.5;
        // trackballControls.panSpeed = 1.0;
        // trackballControls.staticMoving = true;
        // trackballControls.noZoom=false;
        // trackballControls.noPan=false;
        // const clock = new THREE.Clock();
        // let box: THREE.BoxHelper; {
        //     const mesh = EVEWorld.addSphere(scene);
        //     box = new THREE.BoxHelper(mesh, new THREE.Color(0xFF6600));
        //     // box.update();
        //     scene.add(box);
        // }
        // const planeGeo = new THREE.PlaneGeometry(w, h, 10, 10);
        // const planeMat = new THREE.MeshLambertMaterial({
        //     color: 0xffffff,
        //     map: renderTarget,
        //     side: THREE.DoubleSide
        // });
        // const sceneMain = new THREE.Scene();
        const _consumeStepQueue = () => {
            // EaseDeltaContext
            const step = lasq.step;
            // length of step queue.
            const deltaEnd = step.duration;
            if (++easeTimeDelta <= deltaEnd) {
                const easeFn = lasq.easeFn;
                /*if (lasq.lastCameraPosition) {
                    const lerpDelta = easeFn(easeTimeDelta, 0, 1, stepEnd);
                    // const cpos =
                    camera.position.lerp(lasq.lastCameraPosition, lerpDelta);
                    // const cpos = camera.position.lerp(lasq.lastCameraPosition, easeTimeDelta * (1 / stepEnd));
                    if (orbit.target !== lasq.target) {
                        // console.log("diff!!");
                        orbit.target = lasq.target;
                        orbit2.target = lasq.target;
                    }
                } else {
                    const startv3 = step.stv3;
                    // update orbit controll target vector3.
                    const v3 = orbit.target;
                    v3.x = easeFn(easeTimeDelta, startv3.x, step.x, stepEnd);
                    v3.y = easeFn(easeTimeDelta, startv3.y, step.y, stepEnd);
                    v3.z = easeFn(easeTimeDelta, startv3.z, step.z, stepEnd);
                    // camera.lookAt(v3);
                    // DEVNOTE: 1/17/2019, 10:38:49 PM
                    //  With this assign, look at animation has become visible from the beginning.
                    orbit2.target = v3;
                    EASE_TRACE && lasq.trace.push(v3.clone());
                }*/
                if (lasq.lastCameraPosition) {
                    const lerpDelta = easeFn(easeTimeDelta, 0, 1, deltaEnd);
                    // const cpos =
                    camera.position.lerp(lasq.lastCameraPosition, lerpDelta);
                    // const cpos = camera.position.lerp(lasq.lastCameraPosition, easeTimeDelta * (1 / stepEnd));
                }
                const from = step.from;
                // update orbit controll target vector3 */
                const v3 = orbit.target;
                v3.x = easeFn(easeTimeDelta, from.x, step.x, deltaEnd);
                v3.y = easeFn(easeTimeDelta, from.y, step.y, deltaEnd);
                v3.z = easeFn(easeTimeDelta, from.z, step.z, deltaEnd);
                // camera.lookAt(v3);
                // DEVNOTE: 1/17/2019, 10:38:49 PM
                //  With this assign, look at animation has become visible from the beginning.?
                // orbit2.target = v3;
                EASE_TRACE && lasq.trace.push(v3.clone());
            }
            else {
                // DEVNOTE: 1/11/2019, 1:28:56 PM:
                //  While "lookAt" is not required during updating,
                //  it seems to be necessary to update three values here.
                //  It means that drawing of webgl context is executed a little later.
                //   -> maybe, It is not completely synchronized with javascript processing.
                if (lasq.lastCameraPosition) {
                    camera.position.copy(lasq.lastCameraPosition);
                }
                const _target = lasq.target;
                camera.lookAt(_target);
                orbit.target = _target;
                // need assign.
                orbit2.target = _target;
                // console.log(
                //     JSON.stringify(lookAtStepQueue.trace, null, 2)
                // );
                EASE_TRACE && console.log(lasq.trace);
                lasq = null;
                easeTimeDelta = 0;
            }
        };
        let frame = 0;
        let prevLookAtDistance = 0;
        let isNormalView = true;
        const render = ( /*tick?: number*/) => {
            requestAnimationFrame(render);
            // reduce fps - https://ics.media/entry/12930
            if (WorldConfig.reduceFps && frame++ % 2)
                return;
            // console.log(tick);
            // 72453.005
            // 72469.709
            // 72486.402
            // tick around 60fps
            stats.update();
            const currentLookAtDistance = EVEWorld.distanceToLookAt();
            if (prevLookAtDistance ^ currentLookAtDistance) {
                prevLookAtDistance = currentLookAtDistance;
                View.updateLookAtDistance();
            }
            if (lasq) {
                _consumeStepQueue();
            }
            // var delta = clock.getDelta();
            // trackballControls.update();
            // DEVNOTE: need update for animate.
            orbit.update();
            orbit2.update();
            if (wconfig.moveCamera) {
                // DEVNOTE: ここで意図するのは cylinder 状に展開した radius に沿って回転する camera です.
                //  つまり、xz 平面上(horizontal plane)の円を回転しながら lookAt position を camera が向くということ.
                if (!isCameraMvActive) {
                    isCameraMvActive = true;
                    _updateDegAndRad(camera, orbit);
                }
                _rotateCamera(wconfig.stepOfRotateY, camera, orbit);
            }
            else {
                if (isCameraMvActive) {
                    isCameraMvActive = false;
                }
            }
            if (WorldConfig.helperMode) {
                !isNormalView || (isNormalView = false,
                    orbit.dispose(), orbit2.dispose(),
                    orbitHelper.bindEvents(),
                    cam4render = objectiveCamera);
                ThreeComponents.cameraHelper.update();
            }
            else {
                isNormalView || (isNormalView = true,
                    orbit.bindEvents(), orbit2.bindEvents(),
                    orbitHelper.dispose(),
                    cam4render = camera);
            }
            webGLRenderer.render(scene, cam4render /* , renderTarget */);
            labelRenderer.render(scene, cam4render /* , renderTarget */);
        };
        const IGNORE_NAMES = [SYSTEM_HUNTER_NAME, WORLD_CENTER_NAME];
        /** Ray casting event handlers. */
        const rayCastEvents = {
            /** mouse position for 2d unit. */
            mousePos: { x: 0, y: 0 },
            // DEVNOTE: 1/18/2019, 3:20:08 AM - close up on click. (experimental
            // FIXME: accuracy related problem
            selectByMouse: (e) => {
                if (huntedPoint) {
                    e.preventDefault();
                    const size = labelRenderer.getSize();
                    // get position from screen
                    const project = huntedPoint.clone().project(cam4render);
                    const sx = size.width / 2 * (+project.x + 1.0);
                    const sy = size.height / 2 * (-project.y + 1.0);
                    const { clientX, clientY } = e;
                    // console.log("sx=%s, sy=%s, clientX=%s, clientY=%s", sx, sy, clientX, clientY);
                    if ((sx >= clientX - 5 && sx <= clientX + 5) &&
                        (sy >= clientY - 5 && sy <= clientY + 5)) {
                        // DEVNOTE: 2022/02/12 - but EVEWorld always use normal camera, so need related position from that.
                        EVEWorld.lookAt(huntedPoint) && AppEffects.emit(ConfigUI.TagSystemCloseUp);
                        huntedPoint = null;
                        if (systemData) {
                            console.log(systemData);
                            systemData = null;
                        }
                    }
                }
            },
            rayCastingByMouse: (e) => {
                // $consumeEvent(e);
                e.preventDefault();
                Util.mousePositionForRayCasting(e, rayCastEvents.mousePos);
                // DEVNOTE: 2022/2/12 - ray casting from selected camera
                raycaster.setFromCamera(rayCastEvents.mousePos, cam4render);
                // check intersects
                const intersects = raycaster.intersectObjects(scene.children, true);
                const intersect = Util.findIntersectedSystem(intersects, IGNORE_NAMES);
                // DEVNOTE: lasq === null, means camera animation running.
                if (lasq === null && intersect) {
                    // console.log(intersect);
                    let sysdata;
                    // let target: THREE.Vector3;
                    if (intersect.object.type === "Points") { // Minor system.
                        // let pointedIdx = intersect.index!;
                        // sysdata = (intersect.object.userData as RegionUserData).systemList[pointedIdx];
                        // // TODO: bottom up to extend THREE.Points class.
                        // const geo: THREE.BufferGeometry = (<THREE.Points>iobject).geometry as THREE.BufferGeometry;
                        // const f32 = geo.attributes.position.array as Float32Array;
                        // target = new THREE.Vector3(f32[pointedIdx *= 3], f32[pointedIdx + 1], f32[pointedIdx + 2]);
                        sysdata = intersect.object.userData.systemList[intersect.index];
                    }
                    else /* if (intersect.object.type === "Mesh") */ { // means THREE.Mesh, Major system.
                        // target = (intersect.object as THREE.Mesh).position;
                        sysdata = intersect.object.userData;
                    }
                    // debug
                    EVEWorld.fireSystemHunted(sysdata);
                }
            }
        };
        /** create eve world. */
        EVEWorld.emitWorld(scene).then(() => {
            // DEVNOTE: need dat.GUI initialize here. (because add region names
            ConfigUI.initGUI(SYSTEM_HUNTER_NAME);
            ConfigUI.addAnnotationToGui();
            // TODO: 2022/1/19 8:13:44 There is a problem that mouse event does not work properly when displaying aixs and grid.
            // DEVNOTE: not webGLRenderer
            labelRenderer.domElement.addEventListener("mousemove", rayCastEvents.rayCastingByMouse);
            // DEVNOTE: experimental implementation.
            labelRenderer.domElement.addEventListener("mousedown", rayCastEvents.selectByMouse);
            /** add "eve" sphere to world origin. */
            EVEWorld.addSphere(scene);
            createPointerSphere(scene);
            // DEVNOTE: must call render before.
            _updateDegAndRad(camera, orbit);
            // resize event.
            window.addEventListener("resize", () => {
                const w = window.innerWidth;
                const h = window.innerHeight;
                webGLRenderer.setSize(w, h);
                labelRenderer.setSize(w, h);
                cam4render.aspect = w / h;
                cam4render.updateProjectionMatrix();
                // if (WorldConfig.helperMode) {
                //     objectiveCamera.aspect = w / h;
                //     objectiveCamera.updateProjectionMatrix();
                // } else {
                //     camera.aspect = w / h;
                //     camera.updateProjectionMatrix();
                // }
            }, false);
            // lookat world center.
            EVEWorld.defaultCameraPosition();
            /** higher quality */
            requestAnimationFrame(render);
            /** poor quality */
            // window.setInterval(render, 33);
        });
        // AppEffects.createSequencialAudio("hunt", "resources/sounds/ken.wav", 4);
        AppEffects.loadDefault();
        // (() => {
        // const ret = AppEffects.createSequencialAudio("noct48c", "resources/noct48c.mp3", 1);
        // console.log("loaded extra music;", ret);
        // }).emitDefer();
    };
    // globalize
    window.EVEWorld = _EVEWorld;
    window.Mazh = Util.Mazh;
    /**
     * expose to global scope.
     * call by loader script
     * @date 2022/2/9
     */
    window.runEVEWorld = (callback) => {
        // if (typeof EVESystemCoordinates === "undefined") {
        //     console.log("waiting for EVE System Cordinate data...");
        //     return setTimeout(init, 200);
        // }
        console.time(TIME_TAG);
        initEVEWorld().then(() => {
            console.timeEnd(TIME_TAG);
            // DEVNOTE: should be mute state.
            AppEffects.setMute(true);
            $query("button.dummy-button").addEventListener("click", (e) => {
                // const img = $query<HTMLImageElement>("img.effect-button", this);
                // const enable = img.classList.toggle("effect-enable");
                // const token = enable ? "up": "off";
                // img.src = `./resources/round_volume_${token}_white_2x.png`;
                const ds = e.currentTarget.dataset;
                ds.state = ds.state === "on" && "off" || "on";
                // AppEffects.setMute.emitDefer(10, null, ds.state !== "on");
                setTimeout(() => AppEffects.setMute(ds.state !== "on"), 33);
            });
            typeof callback === "function" && callback();
        });
    };
    // window.addEventListener("load", initEVEWorld, { once: true });
}
