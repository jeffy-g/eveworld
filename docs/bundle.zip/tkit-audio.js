/*
"hunt", "resources/sounds/ken.wav", 4
"AudioContext": [
    {
      "tag": "hunt",
      "src": "resources/sounds/ken.wav",
      "size": 4
    },
]
 */
/**
 * `example:`
 *```
 *    AppEffects.createSequencialAudio(
 *        "tick", "resources/sounds/tick.wav", 5
 *    );
 *    let __idx = 0;
 *    let _tid = setInterval(function() {
 *       AppEffects.sequencialPlay("tick");
 *    }, 50);
 * ...
 *```
 */
var _AppEffects;
(function (_AppEffects) {
    // bound resource.
    const EffectList = [
        {
            "tag": "about",
            "src": "resources/fx/about.mp3",
            "size": 1
        },
        {
            "tag": "delete",
            "src": "resources/fx/delete.mp3",
            "size": 1
        },
        {
            "tag": "doit",
            "src": "resources/fx/doit.mp3",
            "size": 1
        },
        {
            "tag": "fadein",
            "src": "resources/fx/fadein.wav",
            "size": 1
        },
        {
            "tag": "fadeout",
            "src": "resources/fx/fadeout.mp3",
            "size": 1
        },
        {
            "tag": "pon",
            "src": "resources/fx/pon.mp3",
            "size": 1
        },
        {
            "tag": "ken",
            "src": "resources/fx/ken.mp3",
            "size": 1
        },
        {
            "tag": "pin",
            "src": "resources/fx/pin.mp3",
            "size": 1
        },
        {
            "tag": "sort",
            "src": "resources/fx/sort.mp3",
            "size": 1
        },
        {
            "tag": "tick",
            "src": "resources/fx/tick.wav",
            "size": 3
        },
        {
            "tag": "update",
            "src": "resources/fx/update.wav",
            "size": 1
        }
    ];
    let _defaultLoadedTags;
    /**
     *
     */
    function loadDefault() {
        _defaultLoadedTags = createSequencialAudio(EffectList);
        console.log("AppEffects::load ->", _defaultLoadedTags);
    }
    _AppEffects.loadDefault = loadDefault;
    function getDefaultTagList() {
        return _defaultLoadedTags;
        // return EffectList.map(entry => {
        //     return entry.tag;
        // });
    }
    _AppEffects.getDefaultTagList = getDefaultTagList;
    const __DEBUG = false;
    /**
     * tag: ISequencialAudio
     */
    const sound_registory = {};
    /**
     * mute sounds, for temporary use.
     */
    let G_MUTE = !1;
    HTMLAudioElement.prototype.stop = function () {
        this.pause();
        this.currentTime = 0;
    };
    /**
     * TODO: 2017/8/15 17:17:31 改善の余地あり
     */
    class SequencialAudio {
        // private src: string
        /**
         *
         */
        constructor(src, size) {
            this.src = src;
            this.init(size);
        }
        // 2017/8/15 17:13:36
        init(size) {
            let a = [];
            this.size = size;
            while (size--) {
                a[size] = new Audio(this.src);
            }
            this.audio = a;
            this.index = 0;
        }
        // CHANGES: 1/16/2019, 10:48:23 PM - fix some resource problem.(? maybe
        //  -> 1/16/2019, 11:03:27 PM - not fixed yet...
        // DEVNOTE: 1/18/2019, 12:08:22 AM
        // see: https://stackoverflow.com/questions/49930680/how-to-handle-uncaught-in-promise-domexception-play-failed-because-the-use
        //  -> Apparently it seems to be error if you do not take any action on the document first.
        //  or
        // 1. Open chrome://flags/#autoplay-policy
        // 2. Setting No user gesture is required
        // 3. Relaunch Chrome
        play() {
            if (G_MUTE)
                return;
            const a = this.audio[this.index++ % this.size];
            a.play();
            // if (a.networkState === HTMLMediaElement.NETWORK_IDLE ) {
            //     a.play(); // this validation were meaningless... :-(
            // } else {
            //     console.log("waitting resource load done...?");
            // }
        }
        pause() {
            for (let a of this.audio) {
                a && a.pause();
            }
        }
        stop() {
            for (let a of this.audio) {
                a && a.stop();
            }
        }
        /**
         * array instance は破棄しない.
         */
        destroy() {
            let size = this.size;
            while (size--) {
                this.audio[size] = null;
            }
            this.audio.length = this.size = 0;
        }
        setVolume(volume) {
            for (let a of this.audio) {
                a && (a.volume = volume);
            }
        }
    }
    function _csa(tag, src, size) {
        // let sa = sound_registory[tag];
        // if (!sa) {
        //     sound_registory[tag] = new SequencialAudio(src, size);
        //     return true;
        // }
        // return false;
        return !sound_registory[tag] && (sound_registory[tag] = new SequencialAudio(src, size), !0);
    }
    /*
     * __SOLUTION OF__:
     * How to handle "Uncaught (in promise) DOMException: play() failed because the user didn't interact with the document first." on Desktop with Chrome 66?
     *  -> There was no effect.
     *     TODO: You need to try other methods.
     */
    // let interfereWithDocument = false;
    /**
     * when created new instance then returns "true". otherwise returns "false".
     * @param {string | SequencialAudioContext[]} tag
     * @param src
     * @param size
     * @return {boolean|string[]} 単体でrequest した場合は boolean, contenxt の場合は create された tag array
     */
    // FIXME: 2018-6-25 parameter に union を使っているため実装が曖昧になっている
    function createSequencialAudio(tag, src, size) {
        // if (!interfereWithDocument) {
        //     interfereWithDocument = true;
        //     const _iwd = () => {
        //         // const button = document.createElement("button");
        //         // button.addEventListener("click", () => {
        //         //     console.log("AppEffects: interfere with document");
        //         //     // button.remove();
        //         // }, { once: true });
        //         // button.style.cssText = "position: absolute; left: -1000px";
        //         // document.body.append(button);
        //         // button.click();
        //         // document.addEventListener("click", () => {
        //         //     console.log("AppEffects: interfere with document");
        //         // }, { once: true });
        //         console.log("AppEffects: interfere with document");
        //         document.body.click();
        //         window.scrollTo(0,0);
        //     };
        //     const _defer = () => {
        //         setTimeout(_iwd, 2000);
        //     };
        //     if (document.readyState !== "complete") {
        //         window.addEventListener("load", _defer, { once: true });
        //     } else {
        //         _defer();
        //     }
        // }
        if (typeof tag === "string") {
            return _csa(tag, src, size);
        }
        else if (Array.isArray(tag)) {
            const contexts = tag;
            let tags = [];
            for (let context of contexts) {
                if (_csa(context.tag, context.src, context.size)) {
                    tags.push(context.tag);
                }
            }
            return tags;
        }
        return false;
    }
    _AppEffects.createSequencialAudio = createSequencialAudio;
    /**
     * tag に関連付けられた sequencial audio を play.
     * 存在しない場合は何もしません.
     * @param tag
     */
    function sequencialPlay(tag) {
        let sa = sound_registory[tag];
        sa && sa.play();
    }
    _AppEffects.sequencialPlay = sequencialPlay;
    // const _emit = (tag: string): void => {
    //     let sa = sound_registory[tag];
    //     sa && sa.play();
    // };
    /**
     * short hand the "sequencialPlay".
     * divide process
     * @param tag
     */
    function emit(tag) {
        // NOTE: 2017/7/30 4:02:39 これは必要ないかもしれない...
        // audio 専用 thread が走っているか？
        // _emit.emitDefer(20, null, tag);
        let sa = sound_registory[tag];
        sa && sa.play();
    }
    _AppEffects.emit = emit;
    /**
     * sound mute temporary.
     * @param is
     */
    function setMute(is) {
        G_MUTE = is;
    }
    _AppEffects.setMute = setMute;
    /**
     *
     * @param tag
     */
    function sequencialStop(tag) {
        let sa = sound_registory[tag];
        sa && sa.stop();
    }
    _AppEffects.sequencialStop = sequencialStop;
    function sequencialStopAll() {
        let tags = Object.keys(sound_registory);
        if (tags) {
            for (let tag of tags) {
                _AppEffects.sequencialStop(tag);
            }
        }
    }
    _AppEffects.sequencialStopAll = sequencialStopAll;
    /**
     *
     * @param tag
     */
    function destroy(tag) {
        let sa = sound_registory[tag];
        if (sa) {
            sa.destroy();
            let success = delete sound_registory[tag];
            __DEBUG && console.log("AppEffects::destroy(%s) success: %s", tag, success);
            return success;
        }
        return false;
    }
    _AppEffects.destroy = destroy;
    /**
     * #### purge all created effect sound.
     * usage for `window.onunload` event.
     */
    function purgeAll() {
        let tags = Object.keys(sound_registory);
        if (tags) {
            let success_list = [];
            for (let tag of tags) {
                _AppEffects.destroy(tag) && success_list.push(tag);
            }
            console.log("purge success : [%s]", success_list.join(", "));
        }
    }
    _AppEffects.purgeAll = purgeAll;
    /**
     * set volume between 0 to 1. (floating number
     *
     * @param tag
     * @param volume
     */
    function setVolume(tag, volume) {
        if (volume < 0)
            volume = 0;
        else if (volume > 1)
            volume = 1;
        let sa = sound_registory[tag];
        sa && sa.setVolume(volume);
    }
    _AppEffects.setVolume = setVolume;
    function setVolumeAll(volume) {
        let tags = Object.keys(sound_registory);
        if (tags) {
            for (let tag of tags) {
                _AppEffects.setVolume(tag, volume);
            }
        }
    }
    _AppEffects.setVolumeAll = setVolumeAll;
    function pause(tag) {
        let sa = sound_registory[tag];
        sa && sa.pause();
    }
    _AppEffects.pause = pause;
})(_AppEffects || (_AppEffects = {}));
window.AppEffects = _AppEffects;
export default void 0;
