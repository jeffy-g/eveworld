/*!
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  Copyright (C) 2019 jeffy-g <hirotom1107@gmail.com>
  Released under the MIT license
  https://opensource.org/licenses/mit-license.php
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                             imports.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// import * as THREE from "three";
import UniverseUnit from "eveworld/universe-unit.js";
import { WorldConfig } from "eveworld/config.js";
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                      module vars, functions.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                    class or namespace declare.
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
/** css2d text instance name as "ID". */
const TEXT_ID = "sphere-title-text";
export class TitiledSphereMesh extends THREE.Mesh {
    constructor(radius, sphereDivision, className = "") {
        super(new THREE.SphereBufferGeometry(radius, sphereDivision, sphereDivision), new THREE.MeshBasicMaterial({
            opacity: 0.4,
            transparent: true,
            // wireframe: true
        }));
        this.sphereDivision = sphereDivision;
        // this.name = "PointerSphere";
        this.type = "TitiledSphereMesh";
        // className === void 0 && (className = "");
        const css2d = View.createCSS2DText("", 0, radius, 0, { className, scale: 0.85 });
        css2d.name = TEXT_ID;
        super.add(css2d);
    }
    setText(text) {
        const css2d = super.getObjectByName(TEXT_ID);
        css2d.element.textContent = text;
        return css2d.element;
    }
    setOpacity(op) {
        const m = this.material;
        m.opacity = op;
        m.needsUpdate = true;
    }
    useWireFrame(is) {
        const m = this.material;
        m.wireframe = is;
        m.needsUpdate = true;
    }
    setRadius(radius, div = this.sphereDivision) {
        // const geo = this.geometry as THREE.SphereBufferGeometry;
        this.geometry.dispose();
        // DEVNOTE: cannot update these code. must reconstruct.
        // geo.parameters.radius = radius;
        this.geometry = new THREE.SphereBufferGeometry(radius, div, div);
        // (<THREE.MeshBasicMaterial>this.material).needsUpdate = true;
    }
}
/**
 * Here, we define the object related to EVEWorld and the utility function for visualizing detailed information.
 */
var View;
(function (View) {
    /**
     * create texture from canvas 2d context.
     *
     * also applied followings:
     * ```ts
     * texture.minFilter = THREE.NearestFilter;
     * texture.premultiplyAlpha = alpah;
     * texture.needsUpdate = true;
     * ```
     *
     * see: https://codepen.io/motrohi/pen/PXzMKN
     *
     * @date 2019-01-21
     * @export
     * @param {boolean} [sharpness=false]
     * @param {boolean} [alpah=true]
     * @returns {THREE.Texture}
     */
    function createSystemTexture(sharpness = false, alpah = true) {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        canvas.width = 128;
        canvas.height = 128;
        const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
        if (sharpness) {
            const stop0 = WorldConfig.colorStop0;
            const stop1 = WorldConfig.colorStop1;
            const stop2 = WorldConfig.colorStop2;
            // grad.addColorStop(0.0, "rgba(255, 255, 255, 1)");
            // grad.addColorStop(0.55, "rgba(255, 255, 255, 0.8)");
            // grad.addColorStop(0.8, "rgba(255, 255, 255, 0.2)");
            // grad.addColorStop(1.0, "rgba(255, 255, 255, 0)");
            grad.addColorStop(stop0, "rgba(255, 255, 255, 1)");
            grad.addColorStop(stop1, "rgba(255, 255, 255, 0.8)");
            grad.addColorStop(stop2, "rgba(255, 255, 255, 0.2)");
            grad.addColorStop(1.0, "rgba(255, 255, 255, 0)");
        }
        else {
            grad.addColorStop(0.0, "rgba(255, 255, 255, 1)");
            grad.addColorStop(0.1, "rgba(255, 255, 255, 0.8)");
            grad.addColorStop(0.3, "rgba(255, 255, 255, 0.2)");
            grad.addColorStop(1.0, "rgba(255, 255, 255, 0)");
        }
        ctx.fillStyle = grad;
        ctx.arc(64, 64, 64, 0, Math.PI / 180, true);
        ctx.fill();
        const texture = new THREE.Texture(canvas);
        // DEVNOTE: `premultiplyAlpha`, see - https://threejs.org/examples/#webgl_materials_blending_custom
        texture.premultiplyAlpha = alpah;
        texture.minFilter = THREE.NearestFilter;
        // DEVNOTE: 1/23/2019, 2:22:05 AM - https://discourse.threejs.org/t/whats-this-about-gammafactor/4264
        texture.encoding = THREE.sRGBEncoding;
        texture.needsUpdate = true;
        return texture;
    }
    View.createSystemTexture = createSystemTexture;
    /**
     * granted css class "name-label".
     *
     * @date 2019-01-11
     * @export
     * @param {string} [text="---"]
     * @param {number} [x=0]
     * @param {number} [y=0]
     * @param {number} [z=0]
     * @param {{ rgba?: string, className?: string, scale?: number }} css
     * @returns {THREE.CSS2DObject}
     */
    function createCSS2DText(text = "---", x = 0, y = 0, z = 0, 
    // position: THREE.Vector3,
    css = {}) {
        const divLabel = document.createElement("div");
        divLabel.className = "name-label";
        // apply assign not empty or valid string.
        divLabel.textContent = text;
        if (css.rgba) {
            divLabel.style.color = css.rgba;
        }
        if (css.className) {
            css.className.split(/,| /g).forEach(
            // must check empty token.
            clazz => clazz && divLabel.classList.add(clazz));
        }
        // @ts- ignore
        const wglLabel = new THREE.CSS2DObject(divLabel, css.scale);
        wglLabel.position.set(x, y, z);
        return wglLabel;
    }
    View.createCSS2DText = createCSS2DText;
    /**
     * **create extra infomation pane**
     *
     *  1. using ease functoin name.
     *
     *  2. camera "lookAt" distance.
     *
     *  3. Distance to selected System.
     *
     */
    function createExtraElements() {
        const tags = `
<div class="extra-stat">
    <span>USING EASE: </span>
    <span class="ease-function"></span> | LOOKAT DISTANCE: <span
    class="lookat-distance" data-unit="LY,"></span>
    <span class="lookat-distance" data-unit="AU,"></span>
    <span class="lookat-distance" data-unit="km;"></span>
</div>
<div class="extra-stat">
    <span>Distance to selected System: </span>
    <span class="hunted-distance" data-unit="LY"></span>
</div>`;
        $dom("stats-container").innerHTML = tags;
    }
    // toLocaleString
    const localeOption = { minimumFractionDigits: 3, maximumFractionDigits: 3 };
    // toLocaleString
    const localLang = navigator.language;
    function updateEaseFunctionInfo(name) {
        $query(".ease-function").textContent = name;
    }
    View.updateEaseFunctionInfo = updateEaseFunctionInfo;
    /**
     * output length of distance to "lookAt". as "LY", "AU" and "km".
     *
     * distination: ".lookat-distance" selector elements.
     */
    function updateLookAtDistance() {
        const lookatDistance = EVEWorld.distanceToLookAt();
        // DEVNOTE: 2020/5/4 1:46:05 - NodeListOf is not Array
        const [ly, au, km] = Array.from($queryAll(".lookat-distance"));
        ly.textContent = (lookatDistance / UniverseUnit.LY).toFixed(8);
        au.textContent = (lookatDistance / UniverseUnit.AU).toLocaleString(localLang, localeOption);
        km.textContent = (lookatDistance / 1000).toLocaleString(localLang, localeOption);
    }
    View.updateLookAtDistance = updateLookAtDistance;
    function updateHuntedDistance(distance) {
        $query(".hunted-distance").textContent = (distance / UniverseUnit.LY).toFixed(8);
        // console.log(`${distance / UniverseUnit.LY} LY`);
    }
    View.updateHuntedDistance = updateHuntedDistance;
    /** DEVNOTE:
     *   Previously, I used very large values like 50_000_000.
     *   Therefore, when building CamereHelper, boundingSphere calculation overflowed, THREE API throw error.
     *
     * ```
     * // Computed radius is NaN. The "position" attribute is likely to have NaN values.
     * THREE.BufferGeometry.computeBoundingSphere();
     * ```
     */
    const MAX_FAR = 974.91; // A value greater than this will result in error. (974.92 etc
    let helperCreated = false;
    function createHelpers(scene, camera) {
        if (!helperCreated) {
            console.log("View::createHelpers");
            //
            // CameraHelper:
            //
            /** see example: https://threejs.org/examples/#webgl_geometry_extrude_splines */
            const cameraHelper = new THREE.CameraHelper(camera);
            cameraHelper.visible = WorldConfig.helperMode;
            //
            // objectiveCamera:
            //
            const objectiveCamera = new THREE.PerspectiveCamera(40, window.innerWidth / window.innerHeight, 1000, UniverseUnit.ly(5000));
            {
                const ly = UniverseUnit.ly(100);
                objectiveCamera.position.set(ly, ly * 4, ly);
                objectiveCamera.lookAt(0, 0, 0);
            }
            //
            // PolarGridHelper:
            //
            let gridHelper;
            {
                const radius = UniverseUnit.ly(64);
                const radials = 16;
                const circles = 16;
                // const divisions = 64;
                // PolarGridHelper(radius?, radials?, circles?, divisions?, color1?, color2?)
                gridHelper = new THREE.PolarGridHelper(radius, radials, circles, 128, new THREE.Color(0x343434), new THREE.Color(0x565656));
                gridHelper.visible = WorldConfig.showGrid;
            }
            //
            // AxesHelper:
            //
            const axes = new THREE.AxesHelper(UniverseUnit.ly(50));
            // (axes.material as THREE.LineBasicMaterial).linewidth = 0.5;
            axes.visible = WorldConfig.showAxes;
            scene.add(new THREE.Object3D().add(axes, gridHelper, cameraHelper, objectiveCamera));
            helperCreated = true;
            return {
                axes,
                gridHelper,
                cameraHelper,
                objectiveCamera,
                orbitHelper: new THREE.OrbitControls(objectiveCamera),
            };
        }
        return {};
    }
    View.createHelpers = createHelpers;
    /**
     * get THREE related object when not created call `createTHREERelated` method.
     */
    function getTHREERelated() {
        if (typeof ThreeComponents === "undefined") {
            return createTHREERelated();
        }
        else {
            return ThreeComponents;
        }
    }
    View.getTHREERelated = getTHREERelated;
    /**
     * create THREE related object.
     *
     *  + NOTE: `ThreeComponents` expose to window
     *
     * @param {number} [width] default: window.innerWidth
     * @param {number} [height] default: window.innerHeight
     */
    function createTHREERelated(width = window.innerWidth, height = window.innerHeight) {
        createExtraElements();
        const stats = new Stats();
        {
            // REVISION: 11
            // stats.setMode(0); // 0: fps, 1: ms
            // // Align top-left
            // stats.domElement.className = "webgl-stats";
            // $dom("stats-container").append(stats.domElement);
            // REVISION: 16
            stats.showPanel(0);
            // class name for selector.
            stats.dom.className = "webgl-stats";
            $dom("stats-container").append(stats.dom);
        }
        const scene = new THREE.Scene();
        // see: https://matorel.com/archives/519 [Three JS:基本の使い方総まとめ-Light > DirectionalLight編-]
        // const light = new THREE.DirectionalLight(0xFFFFFF, 1);
        // light.position.set(0, UniverseUnit.ly(200), UniverseUnit.ly(80));
        // light.castShadow = true;
        // scene.add(light);
        // const directionalLightHelper = new THREE.DirectionalLightHelper(light);
        // scene.add( directionalLightHelper);
        // - - - OrthographicCamera, Caution!
        // use http://themetalmuncher.github.io/fov-calc/ UniverseUnit.ly(500)
        // 1 micrometer(1e-6) to 0.5 billion light years in one scene, with 1 unit = 1 meter
        // const camera: THREE.Camera = new THREE.OrthographicCamera(
        //     -(UniverseUnit.ly(50)), UniverseUnit.ly(50),
        //     UniverseUnit.ly(50), -(UniverseUnit.ly(50)),
        //     1_000, UniverseUnit.ly(MAX_FAR)
        // );
        // - - - PerspectiveCamera
        // DEVNOTE: 1/8/2019, 9:11:00 PM - be careful for "near" parameter.
        // because when value were too small fail THREE.Raycaster's test.
        const camera = new THREE.PerspectiveCamera(WorldConfig.fov, width / height, 1000, UniverseUnit.ly(MAX_FAR));
        // for helper?
        scene.add(camera);
        // - - - Raycaster
        const raycaster = new THREE.Raycaster();
        raycaster.params.Points.threshold = UniverseUnit.LY * WorldConfig["Ray threshold(LY)"];
        // - - - WebGLRenderer
        const webGLRenderer = new THREE.WebGLRenderer({
            antialias: true,
            logarithmicDepthBuffer: true,
            preserveDrawingBuffer: true,
            powerPreference: "high-performance"
        });
        webGLRenderer.domElement.classList.add("eve-world");
        webGLRenderer.setClearColor(0x000000, 1.0);
        webGLRenderer.setPixelRatio(WorldConfig.PixelRatio);
        webGLRenderer.setSize(width, height);
        // DEVNOTE: gammaFactor already removed at v 0.136
        // webGLRenderer.gammaFactor = WorldConfig.gammaFactor;
        // // DEVNOTE: 2019/12/17 10:35:52 - removed at r112
        // webGLRenderer.gammaInput = WorldConfig.gammaInput;
        // // DEVNOTE: 2019/12/17 10:35:52 - removed at r112
        // webGLRenderer.gammaOutput = WorldConfig.gammaOutput;
        // - - - CSS2DRenderer
        const labelRenderer = new THREE.CSS2DRenderer();
        labelRenderer.setSize(width, height);
        labelRenderer.domElement.classList.add("css2d-view");
        // - - - OrbitControls x 2
        // DEVNOTE: in this case, param2 "domElement" are necessary.
        const orbit = new THREE.OrbitControls(camera, webGLRenderer.domElement);
        const orbit2 = new THREE.OrbitControls(camera, labelRenderer.domElement);
        orbit2.keyPanSpeed = orbit.keyPanSpeed = 0.8;
        orbit.enableDamping = true;
        // defulat: .25
        orbit.dampingFactor = .3; /* 0.5 are bit hard */
        orbit2.enableDamping = true;
        orbit2.dampingFactor = .3;
        // default: true
        // orbit.enablePan = true;
        // @ts-ignore 
        const components = createHelpers(scene, camera);
        return window["ThreeComponents"] = Object.assign(components, {
            stats, orbit, orbit2,
            scene, camera, raycaster,
            // light,
            webGLRenderer, labelRenderer
        });
    }
    View.createTHREERelated = createTHREERelated;
})(View || (View = {}));
export default View;
